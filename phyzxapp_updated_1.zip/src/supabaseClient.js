// Client Supabase "vero" (supabase-js), usato per tutte le funzionalità NUOVE:
// autenticazione (Auth), profili, amicizie, migrazione da account legacy.
// Le funzioni RPC legacy (register_code, login_code, get_workout_data, set_workout_data,
// delete_account, cleanup_abandoned_accounts) restano invece via fetch diretto in App.jsx,
// invariate, per non rischiare di rompere nulla di quel percorso già in produzione.
import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://qprnxbypcoofdnpsngbv.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFwcm54YnlwY29vZmRucHNuZ2J2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ1NzY5MjQsImV4cCI6MjEwMDE1MjkyNH0.lFQnb7pdJ_ghVmHFMFeu_XraouB8URjtriT1gYEeaCE';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  },
});

// Google OAuth predisposto lato Supabase ma non ancora configurato in produzione:
// questo flag permette di nascondere/disabilitare il bottone finché non viene attivato,
// senza dover toccare il codice quando sarà pronto (basterà passare a true).
export const GOOGLE_OAUTH_ENABLED = false;
