import React, { useState, useMemo, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import Papa from 'papaparse';
import { supabase, GOOGLE_OAUTH_ENABLED } from './supabaseClient';

// Configurazione Supabase (progetto dedicato a questa app)
const SUPABASE_URL = 'https://qprnxbypcoofdnpsngbv.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFwcm54YnlwY29vZmRucHNuZ2J2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ1NzY5MjQsImV4cCI6MjEwMDE1MjkyNH0.lFQnb7pdJ_ghVmHFMFeu_XraouB8URjtriT1gYEeaCE';

async function supabaseRpc(fnName, params) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fnName}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_ANON_KEY,
      'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    },
    body: JSON.stringify(params),
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    throw new Error((data && data.message) || `Errore server (${res.status})`);
  }
  return data;
}

const registerCode = (code) => supabaseRpc('register_code', { p_code: code });
const loginCode = (code) => supabaseRpc('login_code', { p_code: code });
const getWorkoutData = (userId) => supabaseRpc('get_workout_data', { p_user_id: userId });
const setWorkoutDataRemote = (userId, data) => supabaseRpc('set_workout_data', { p_user_id: userId, p_data: data });
const deleteAccount = (userId) => supabaseRpc('delete_account', { p_user_id: userId });
const cleanupAbandonedAccounts = () => supabaseRpc('cleanup_abandoned_accounts', {});

const LOCAL_STORAGE_KEY = 'performance-log-user-id';
const LANG_APP_KEY = 'performance-log-lang-app';
const LANG_EXERCISE_KEY = 'performance-log-lang-exercise';
const UNITS_KEY = 'performance-log-units';
const MIN_COUNT_KEY_PREFIX = 'performance-log-mincount-';
const DEFAULT_MIN_COUNT = 1;

// Regex username: 3-24 caratteri, lettere (maiuscole e minuscole)/numeri/underscore, allineata al
// constraint del DB. Case sensitive: "Mario" e "mario" sono username diversi.
const USERNAME_REGEX = /^[a-zA-Z0-9_]{3,24}$/;

// Dizionario stringhe interfaccia: italiano e inglese
const UI_STRINGS = {
  it: {
    subtitle: 'Esplora i tuoi allenamenti',
    updateExport: 'Aggiorna con nuovo export',
    manage: 'Gestisci',
    logout: 'Esci',
    back: 'Indietro',
    settings: 'Impostazioni',
    deleteAccount: 'Elimina account',
    deleteAccountConfirm: 'Vuoi eliminare definitivamente il tuo account e tutti i dati salvati? Questa azione non può essere annullata.',
    deleteAccountConfirmFinal: 'Sei sicuro? Tutti i tuoi allenamenti salvati verranno cancellati per sempre.',
    minSetsCount: 'Numero minimo di serie',
    logoutConfirm: 'Vuoi uscire? Potrai riaccedere in qualsiasi momento con il tuo codice personale.',
    tapMuscleGroup: "Tocca un gruppo muscolare per vedere l'andamento",
    sessions: 'sessioni',
    sets: 'serie',
    totalVolume: 'kg volume tot.',
    compareOtherGroup: 'Confronta con esercizio di un altro gruppo',
    max: 'Max',
    last: 'Ultimo',
    strengthChartNote: 'Ogni linea mostra il livello di forza stimato (1RM) di quell\'esercizio nel tempo.',
    zoomHint: 'Trascina o scorri per spostarti, pizzica per zoomare',
    range1m: '1M',
    range3m: '3M',
    range6m: '6M',
    range1y: '1A',
    rangeAll: 'Tutto',
    resetZoom: 'Reimposta',
    latestSessions: 'Ultime sessioni',
    date: 'Data',
    topSet: 'Serie top',
    value: 'Valore',
    mixedNote: 'Questo esercizio ha sia sessioni a corpo libero che con zavorra — le statistiche sopra si basano sulle sessioni con carico.',
    minCountThreshold: 'Soglia minima esecuzioni',
    hiddenAuto: 'esercizi fatti meno volte sono nascosti automaticamente',
    allExercises: 'Tutti gli esercizi',
    tapToToggle: 'tocca per mostrare/nascondere',
    login: 'Accedi',
    register: 'Registrati',
    chooseCode: 'Scegli un codice personale — ti servirà per ritrovare i tuoi dati la prossima volta.',
    enterCode: 'Inserisci il tuo codice personale per accedere ai tuoi dati.',
    codePlaceholder: 'Il tuo codice personale',
    createAccount: 'Crea account',
    pleaseWait: 'Attendere…',
    uploadTitle: 'Carica il tuo export',
    uploadSubtitle: 'Non hai ancora nessun dato salvato. Carica il file CSV esportato dalla tua app per iniziare — verrà salvato sul tuo account e lo ritroverai ad ogni accesso.',
    chooseFile: 'Scegli file CSV',
    uploading: 'Caricamento…',
    loading: 'Caricamento…',
    loadingData: 'Caricamento dati…',
    appLanguage: 'Lingua app',
    exerciseLanguage: 'Lingua esercizi',
    units: 'Unità di misura',
    weightUnit: 'Peso',
    distanceUnit: 'Distanza',
    // --- Nuovo sistema di login (email/password + Google + profilo + amici) ---
    email: 'Email',
    password: 'Password',
    loginWithGoogle: 'Accedi con Google',
    comingSoon: 'Presto disponibile',
    googleNotConfiguredNote: 'La configurazione di Google non è ancora completata.',
    orDivider: 'oppure',
    haveLegacyCode: 'Ho già un account con codice personale',
    legacyMigrationTitle: 'Recupera il tuo vecchio account',
    legacyMigrationIntro: 'Inserisci il codice personale del tuo vecchio account: dopo aver effettuato accesso o registrato un nuovo account email, sposteremo automaticamente i tuoi dati.',
    legacyCodeNotFound: 'Codice non trovato o già utilizzato.',
    legacyMigrationSuccess: 'Dati recuperati con successo dal tuo vecchio account!',
    continueWithEmail: 'Continua con email e password',
    invalidEmail: 'Inserisci un indirizzo email valido.',
    passwordTooShort: 'La password deve avere almeno 6 caratteri.',
    authGenericError: 'Errore imprevisto. Riprova.',
    createProfileTitle: 'Crea il tuo profilo',
    createProfileIntro: 'Scegli uno username univoco per essere trovato dagli amici.',
    username: 'Username',
    usernamePlaceholder: 'es. mario_rossi',
    usernameHint: '3-24 caratteri: lettere, numeri e underscore. Maiuscole e minuscole sono considerate diverse.',
    usernameInvalid: 'Username non valido: usa solo lettere, numeri e underscore (3-24 caratteri).',
    usernameTaken: 'Questo username è già in uso, scegline un altro.',
    avatarUrl: 'Foto profilo',
    changePhoto: 'Cambia foto',
    choosePhoto: 'Scegli una foto',
    removePhoto: 'Rimuovi foto',
    uploadingPhoto: 'Caricamento…',
    photoTooLarge: 'Immagine non valida o troppo grande.',
    photoUploadError: 'Caricamento non riuscito. Riprova.',
    saveProfile: 'Salva profilo',
    friends: 'Amici',
    friendsNeedMigration: 'Gli amici sono disponibili solo per gli account con email/password. Esci e scegli "Ho già un account con codice personale" nella schermata di accesso per collegare il tuo codice a un account vero e sbloccare questa sezione.',
    legacyAccountSettingsHint: 'Il tuo account usa ancora il vecchio codice personale. Per sbloccare profilo pubblico e amici, esci e scegli "Ho già un account con codice personale" nella schermata di accesso: i tuoi dati verranno spostati automaticamente su un account email/password.',
    searchUsername: 'Cerca per username…',
    sendRequest: 'Invia richiesta',
    requestSent: 'Richiesta inviata',
    requestAlreadyExists: 'Avete già una richiesta di amicizia in corso.',
    noResults: 'Nessun risultato',
    pendingRequestsReceived: 'Richieste ricevute',
    noPendingRequests: 'Nessuna richiesta in sospeso',
    accept: 'Accetta',
    decline: 'Rifiuta',
    myFriends: 'I miei amici',
    noFriendsYet: 'Non hai ancora amici. Cercali per username!',
    viewSummary: 'Vedi riepilogo',
    friendSummaryTitle: 'Riepilogo allenamenti',
    firstSession: 'Prima sessione',
    lastSession: 'Ultima sessione',
    summaryLoadError: 'Impossibile caricare il riepilogo (magari non siete più amici).',
    editProfile: 'Modifica profilo',
    profileSaved: 'Profilo salvato.',
    // --- Import multi-app (selezione manuale dell'app di provenienza) ---
    importAppLabel: 'App di provenienza',
    importAppLiftoff: 'Liftoff',
    importAppStrong: 'Strong',
    importAppHevy: 'Hevy',
    importAppJefit: 'Jefit',
    importAppOther: 'Altro formato CSV',
    importMappingTitle: 'Associa le colonne del tuo file',
    importMappingIntro: 'Abbiamo trovato queste colonne nel file: scegli quale corrisponde a ciascun campo richiesto.',
    importMappingDate: 'Colonna Data',
    importMappingExercise: 'Colonna Esercizio',
    importMappingWeight: 'Colonna Peso',
    importMappingReps: 'Colonna Reps',
    importMappingWeightUnit: 'Colonna Unità peso (opzionale)',
    importMappingNone: '(nessuna — usa unità di default)',
    importMappingConfirm: 'Applica mappatura',
    importMappingIncomplete: 'Seleziona almeno le colonne Data, Esercizio, Peso e Reps.',
    importParseError: 'Errore nella lettura del file',
    importNoValidRows: 'Nessuna riga valida trovata nel file. Controlla che il formato scelto corrisponda al file caricato.',
    // --- Cardio ---
    cardio: 'Cardio',
    cardioNeedMigration: 'Il cardio è disponibile solo per gli account con email/password. Esci e scegli "Ho già un account con codice personale" nella schermata di accesso per collegare il tuo codice a un account vero e sbloccare questa sezione.',
    cardioAddSession: 'Nuova sessione cardio',
    cardioActivity: 'Attività',
    cardioActivityRun: 'Corsa',
    cardioActivityWalk: 'Camminata',
    cardioActivityCycle: 'Ciclismo',
    cardioActivitySwim: 'Nuoto',
    cardioActivityOther: 'Altro',
    cardioDuration: 'Durata (min:sec)',
    cardioDistance: 'Distanza (opzionale)',
    cardioNotes: 'Note (opzionale)',
    cardioSave: 'Salva sessione',
    cardioList: 'Sessioni registrate',
    cardioNoSessions: 'Nessuna sessione cardio registrata ancora.',
    cardioDelete: 'Elimina',
    cardioDeleteConfirm: 'Eliminare questa sessione cardio?',
    cardioPaceChart: 'Andamento ritmo (min/km)',
    cardioDurationChart: 'Andamento durata',
    cardioPace: 'Ritmo',
    cardioSaveError: 'Errore nel salvataggio della sessione.',
    cardioLoadError: 'Errore nel caricamento delle sessioni cardio.',
    cardioDeleteError: 'Errore nell\'eliminazione della sessione.',
    cardioDurationInvalid: 'Inserisci una durata valida (maggiore di zero).',
    otherSections: 'Altre sezioni',
    // --- Metriche corporee ---
    bodyMetrics: 'Metriche corporee',
    bodyMetricsNeedMigration: 'Le metriche corporee sono disponibili solo per gli account con email/password. Esci e scegli "Ho già un account con codice personale" nella schermata di accesso per collegare il tuo codice a un account vero e sbloccare questa sezione.',
    bodyWeightTitle: 'Peso corporeo',
    bodyWeightToday: 'Peso di oggi',
    bodyWeightDate: 'Data',
    bodyWeightValue: 'Peso',
    bodyWeightSave: 'Salva peso',
    bodyWeightChart: 'Andamento peso',
    bodyWeightSaveError: 'Errore nel salvataggio del peso.',
    bodyWeightLoadError: 'Errore nel caricamento dello storico peso.',
    bodyWeightInvalid: 'Inserisci un peso valido.',
    bodyHeightTitle: 'Altezza',
    bodyHeightValue: 'Altezza (cm)',
    bodyHeightSave: 'Salva altezza',
    bodyHeightInvalid: 'Inserisci un\'altezza valida.',
    bodyHeightSaveError: 'Errore nel salvataggio dell\'altezza.',
    bodyHeightLoadError: 'Errore nel caricamento dell\'altezza.',
    bmiLabel: 'BMI stimato',
    bmiNote: 'Il BMI è un indicatore approssimativo basato solo su peso e altezza: non tiene conto di composizione corporea, età o altri fattori, e non ha valore diagnostico.',
    measurementsTitle: 'Circonferenze',
    measurementZone: 'Zona',
    measurementValue: 'Circonferenza (cm)',
    measurementDate: 'Data',
    measurementSave: 'Salva misura',
    measurementChart: 'Andamento',
    measurementNoData: 'Nessuna misura registrata per questa zona.',
    measurementSaveError: 'Errore nel salvataggio della misura.',
    measurementLoadError: 'Errore nel caricamento delle misure.',
    measurementInvalid: 'Inserisci un valore valido.',
    zoneWaist: 'Vita',
    zoneChest: 'Petto',
    zoneHips: 'Fianchi',
    zoneBicepsLeft: 'Bicipite sinistro',
    zoneBicepsRight: 'Bicipite destro',
    zoneThighLeft: 'Coscia sinistra',
    zoneThighRight: 'Coscia destra',
    zoneNeck: 'Collo',
    zoneCalfLeft: 'Polpaccio sinistro',
    zoneCalfRight: 'Polpaccio destro',
    close: 'Chiudi',
    save: 'Salva',
    delete: 'Elimina',
    km: 'km',
    mi: 'mi',
  },
  en: {
    subtitle: 'Explore your workouts',
    updateExport: 'Update with new export',
    manage: 'Manage',
    logout: 'Log out',
    back: 'Back',
    deleteAccount: 'Delete account',
    deleteAccountConfirm: 'Do you want to permanently delete your account and all saved data? This action cannot be undone.',
    deleteAccountConfirmFinal: 'Are you sure? All your saved workouts will be deleted forever.',
    minSetsCount: 'Minimum number of sets',
    logoutConfirm: 'Do you want to log out? You can sign back in anytime with your personal code.',
    tapMuscleGroup: 'Tap a muscle group to see progress',
    sessions: 'sessions',
    sets: 'sets',
    totalVolume: 'kg total volume',
    compareOtherGroup: 'Compare with an exercise from another group',
    max: 'Max',
    last: 'Last',
    strengthChartNote: 'Each line shows the estimated strength level (1RM) of that exercise over time.',
    zoomHint: 'Drag or scroll to pan, pinch to zoom',
    range1m: '1M',
    range3m: '3M',
    range6m: '6M',
    range1y: '1Y',
    rangeAll: 'All',
    resetZoom: 'Reset',
    latestSessions: 'Latest sessions',
    date: 'Date',
    topSet: 'Top set',
    value: 'Value',
    mixedNote: 'This exercise has both bodyweight and weighted sessions — the stats above are based on weighted sessions.',
    minCountThreshold: 'Minimum times performed',
    hiddenAuto: 'exercises done fewer times are automatically hidden',
    allExercises: 'All exercises',
    tapToToggle: 'tap to show/hide',
    login: 'Log in',
    register: 'Sign up',
    chooseCode: "Choose a personal code — you'll need it to find your data again next time.",
    enterCode: 'Enter your personal code to access your data.',
    codePlaceholder: 'Your personal code',
    createAccount: 'Create account',
    pleaseWait: 'Please wait…',
    uploadTitle: 'Upload your export',
    uploadSubtitle: "You don't have any saved data yet. Upload the CSV file exported from your app to get started — it will be saved to your account and you'll find it every time you log in.",
    chooseFile: 'Choose CSV file',
    uploading: 'Uploading…',
    loading: 'Loading…',
    loadingData: 'Loading data…',
    settings: 'Settings',
    appLanguage: 'App language',
    exerciseLanguage: 'Exercise language',
    units: 'Units',
    weightUnit: 'Weight',
    distanceUnit: 'Distance',
    // --- New login system (email/password + Google + profile + friends) ---
    email: 'Email',
    password: 'Password',
    loginWithGoogle: 'Log in with Google',
    comingSoon: 'Coming soon',
    googleNotConfiguredNote: 'Google sign-in setup is not finished yet.',
    orDivider: 'or',
    haveLegacyCode: 'I already have an account with a personal code',
    legacyMigrationTitle: 'Recover your old account',
    legacyMigrationIntro: "Enter your old account's personal code: after you sign in or register a new email account, we'll automatically move your data over.",
    legacyCodeNotFound: 'Code not found or already used.',
    legacyMigrationSuccess: 'Data successfully recovered from your old account!',
    continueWithEmail: 'Continue with email and password',
    invalidEmail: 'Enter a valid email address.',
    passwordTooShort: 'Password must be at least 6 characters.',
    authGenericError: 'Unexpected error. Please try again.',
    createProfileTitle: 'Create your profile',
    createProfileIntro: 'Choose a unique username so friends can find you.',
    username: 'Username',
    usernamePlaceholder: 'e.g. john_doe',
    usernameHint: '3-24 characters: letters, numbers and underscores. Uppercase and lowercase are treated as different.',
    usernameInvalid: 'Invalid username: use only letters, numbers and underscores (3-24 characters).',
    usernameTaken: 'This username is already taken, choose another one.',
    avatarUrl: 'Profile picture',
    changePhoto: 'Change photo',
    choosePhoto: 'Choose a photo',
    removePhoto: 'Remove photo',
    uploadingPhoto: 'Uploading…',
    photoTooLarge: 'Invalid image or file too large.',
    photoUploadError: 'Upload failed. Please try again.',
    saveProfile: 'Save profile',
    friends: 'Friends',
    friendsNeedMigration: 'Friends are only available for email/password accounts. Log out and choose "I already have a personal code account" on the sign-in screen to link your code to a real account and unlock this section.',
    legacyAccountSettingsHint: 'Your account still uses the old personal code. To unlock a public profile and friends, log out and choose "I already have a personal code account" on the sign-in screen: your data will be moved automatically to an email/password account.',
    searchUsername: 'Search by username…',
    sendRequest: 'Send request',
    requestSent: 'Request sent',
    requestAlreadyExists: 'You already have a friend request in progress.',
    noResults: 'No results',
    pendingRequestsReceived: 'Requests received',
    noPendingRequests: 'No pending requests',
    accept: 'Accept',
    decline: 'Decline',
    myFriends: 'My friends',
    noFriendsYet: "You don't have any friends yet. Search for them by username!",
    viewSummary: 'View summary',
    friendSummaryTitle: 'Workout summary',
    firstSession: 'First session',
    lastSession: 'Last session',
    summaryLoadError: "Couldn't load the summary (maybe you're not friends anymore).",
    editProfile: 'Edit profile',
    profileSaved: 'Profile saved.',
    // --- Multi-app import (manual selection of source app) ---
    importAppLabel: 'Source app',
    importAppLiftoff: 'Liftoff',
    importAppStrong: 'Strong',
    importAppHevy: 'Hevy',
    importAppJefit: 'Jefit',
    importAppOther: 'Other CSV format',
    importMappingTitle: 'Map your file columns',
    importMappingIntro: 'We found these columns in the file: choose which one matches each required field.',
    importMappingDate: 'Date column',
    importMappingExercise: 'Exercise column',
    importMappingWeight: 'Weight column',
    importMappingReps: 'Reps column',
    importMappingWeightUnit: 'Weight unit column (optional)',
    importMappingNone: '(none — use default unit)',
    importMappingConfirm: 'Apply mapping',
    importMappingIncomplete: 'Select at least the Date, Exercise, Weight and Reps columns.',
    importParseError: 'Error reading the file',
    importNoValidRows: 'No valid rows found in the file. Check that the chosen format matches the uploaded file.',
    // --- Cardio ---
    cardio: 'Cardio',
    cardioNeedMigration: 'Cardio is only available for email/password accounts. Log out and choose "I already have a personal code account" on the sign-in screen to link your code to a real account and unlock this section.',
    cardioAddSession: 'New cardio session',
    cardioActivity: 'Activity',
    cardioActivityRun: 'Running',
    cardioActivityWalk: 'Walking',
    cardioActivityCycle: 'Cycling',
    cardioActivitySwim: 'Swimming',
    cardioActivityOther: 'Other',
    cardioDuration: 'Duration (min:sec)',
    cardioDistance: 'Distance (optional)',
    cardioNotes: 'Notes (optional)',
    cardioSave: 'Save session',
    cardioList: 'Logged sessions',
    cardioNoSessions: 'No cardio sessions logged yet.',
    cardioDelete: 'Delete',
    cardioDeleteConfirm: 'Delete this cardio session?',
    cardioPaceChart: 'Pace trend (min/km)',
    cardioDurationChart: 'Duration trend',
    cardioPace: 'Pace',
    cardioSaveError: 'Error saving the session.',
    cardioLoadError: 'Error loading cardio sessions.',
    cardioDeleteError: 'Error deleting the session.',
    cardioDurationInvalid: 'Enter a valid duration (greater than zero).',
    otherSections: 'Other sections',
    // --- Body metrics ---
    bodyMetrics: 'Body metrics',
    bodyMetricsNeedMigration: 'Body metrics are only available for email/password accounts. Log out and choose "I already have a personal code account" on the sign-in screen to link your code to a real account and unlock this section.',
    bodyWeightTitle: 'Body weight',
    bodyWeightToday: "Today's weight",
    bodyWeightDate: 'Date',
    bodyWeightValue: 'Weight',
    bodyWeightSave: 'Save weight',
    bodyWeightChart: 'Weight trend',
    bodyWeightSaveError: 'Error saving weight.',
    bodyWeightLoadError: 'Error loading weight history.',
    bodyWeightInvalid: 'Enter a valid weight.',
    bodyHeightTitle: 'Height',
    bodyHeightValue: 'Height (cm)',
    bodyHeightSave: 'Save height',
    bodyHeightInvalid: 'Enter a valid height.',
    bodyHeightSaveError: 'Error saving height.',
    bodyHeightLoadError: 'Error loading height.',
    bmiLabel: 'Estimated BMI',
    bmiNote: 'BMI is an approximate indicator based only on weight and height: it does not account for body composition, age, or other factors, and has no diagnostic value.',
    measurementsTitle: 'Body measurements',
    measurementZone: 'Zone',
    measurementValue: 'Measurement (cm)',
    measurementDate: 'Date',
    measurementSave: 'Save measurement',
    measurementChart: 'Trend',
    measurementNoData: 'No measurements logged for this zone.',
    measurementSaveError: 'Error saving the measurement.',
    measurementLoadError: 'Error loading measurements.',
    measurementInvalid: 'Enter a valid value.',
    zoneWaist: 'Waist',
    zoneChest: 'Chest',
    zoneHips: 'Hips',
    zoneBicepsLeft: 'Left biceps',
    zoneBicepsRight: 'Right biceps',
    zoneThighLeft: 'Left thigh',
    zoneThighRight: 'Right thigh',
    zoneNeck: 'Neck',
    zoneCalfLeft: 'Left calf',
    zoneCalfRight: 'Right calf',
    close: 'Close',
    save: 'Save',
    delete: 'Delete',
    km: 'km',
    mi: 'mi',
  },
};

function t(lang, key) {
  return (UI_STRINGS[lang] && UI_STRINGS[lang][key]) || UI_STRINGS.it[key] || key;
}

// Conversioni unità di misura
const KG_TO_LB = 2.20462;
function convertWeight(kg, unit) {
  return unit === 'lb' ? kg * KG_TO_LB : kg;
}
function weightUnitLabel(unit) {
  return unit === 'lb' ? 'lb' : 'kg';
}
function fmtWeight(kgValue, unit) {
  const converted = convertWeight(kgValue, unit);
  return fmtKg(converted);
}

// Fattore di conversione km -> miglia, usato per la distanza cardio quando l'utente ha impostato lb
// (si assume che chi preferisce libbre preferisca anche le miglia per la distanza).
const KM_TO_MI = 0.621371;
function convertDistanceKm(km, weightUnit) {
  return weightUnit === 'lb' ? km * KM_TO_MI : km;
}
function distanceUnitLabel(weightUnit) {
  return weightUnit === 'lb' ? 'mi' : 'km';
}

// Zone di circonferenza corporea supportate: valori esatti dell'enum measurement_type in DB,
// con relativa chiave di traduzione per l'etichetta mostrata.
const MEASUREMENT_ZONES = [
  { key: 'waist', labelKey: 'zoneWaist' },
  { key: 'chest', labelKey: 'zoneChest' },
  { key: 'hips', labelKey: 'zoneHips' },
  { key: 'biceps_left', labelKey: 'zoneBicepsLeft' },
  { key: 'biceps_right', labelKey: 'zoneBicepsRight' },
  { key: 'thigh_left', labelKey: 'zoneThighLeft' },
  { key: 'thigh_right', labelKey: 'zoneThighRight' },
  { key: 'neck', labelKey: 'zoneNeck' },
  { key: 'calf_left', labelKey: 'zoneCalfLeft' },
  { key: 'calf_right', labelKey: 'zoneCalfRight' },
];

// Attività cardio supportate, con relativa chiave di traduzione.
const CARDIO_ACTIVITIES = [
  { key: 'Corsa', labelKey: 'cardioActivityRun' },
  { key: 'Camminata', labelKey: 'cardioActivityWalk' },
  { key: 'Ciclismo', labelKey: 'cardioActivityCycle' },
  { key: 'Nuoto', labelKey: 'cardioActivitySwim' },
  { key: 'Altro', labelKey: 'cardioActivityOther' },
];

const GROUP_ORDER = ['Petto','Schiena','Spalle','Bicipiti','Tricipiti','Gambe','Addominali','Avambracci','Altro'];

const GROUP_COLOR = {
  Petto: '#5ADECD',
  Schiena: '#4FA8D8',
  Spalle: '#8B7FE8',
  Bicipiti: '#5AC9DE',
  Tricipiti: '#C77FE0',
  Gambe: '#7F8FE8',
  Addominali: '#5AE0A8',
  Avambracci: '#5AB8E0',
  Altro: '#9694B0',
};

const LB_TO_KG = 0.453592;

const EXERCISE_TO_GROUP = {
  'Bench Press':'Petto','Dumbbell Bench Press':'Petto','Incline Dumbbell Bench Press':'Petto',
  'Incline Dumbbell Fly':'Petto','Cable Fly':'Petto','High to Low Cable Fly':'Petto',
  'Chest Press':'Petto','Smith Machine Bench Press':'Petto','Smith Machine Incline Bench Press':'Petto',
  'Dips':'Petto','Diamond Push Ups':'Petto','Supine Bench Press':'Petto',
  'Seated Cable Row':'Schiena','Dumbbell Row':'Schiena','Chest Supported Dumbbell Row':'Schiena',
  'Lat Pulldown':'Schiena','One Arm Lat Pulldown':'Schiena','Machine Row':'Schiena',
  'Bent Over Row':'Schiena','Neutral Grip Pull Ups':'Schiena','Pull Ups':'Schiena',
  'Chin Ups':'Schiena','Dead Hang':'Schiena','Back Extension':'Schiena','Deadlift':'Schiena',
  'Face Pull':'Schiena','Cable Reverse Fly':'Schiena','Dumbbell Reverse Fly':'Schiena',
  'One Arm Cable Reverse Fly':'Schiena',
  'Machine Shoulder Press':'Spalle','Seated Dumbbell Shoulder Press':'Spalle','Military Press':'Spalle',
  'Dumbbell Lateral Raise':'Spalle','Cable Lateral Raise':'Spalle','Machine Lateral Raise':'Spalle',
  'Lu Raise':'Spalle','Dumbbell Shrug':'Spalle','Cable Shrug':'Spalle','Machine Shrug':'Spalle',
  'Smith Machine Shrug':'Spalle','60\u00b0 Shrugs':'Spalle','Chest Supported Dumbbell Shrug':'Spalle',
  'EZ Bar Curl':'Bicipiti','EZ Bar Preacher Curl':'Bicipiti','Hammer Curl':'Bicipiti',
  'Incline Dumbbell Curl':'Bicipiti','Cable Hammer Curl':'Bicipiti','Dumbbell Curl':'Bicipiti',
  'Preacher Curl':'Bicipiti','Preacher Hammer Curl':'Bicipiti','Cross Body Hammer Curl':'Bicipiti',
  'Incline Hammer Curl':'Bicipiti','Dumbbell Reverse Curl':'Bicipiti',
  'Tricep Pushdown':'Tricipiti','Seated Dumbbell Tricep Extension':'Tricipiti',
  'Cable Overhead Tricep Extension':'Tricipiti','EZ Bar Lying Tricep Extension':'Tricipiti',
  'JM Press':'Tricipiti','Tricep Extension':'Tricipiti',
  'Squat':'Gambe','Smith Machine Squat':'Gambe','Hack Squat':'Gambe','Leg Extension':'Gambe',
  'Seated Leg Curl':'Gambe','Hip Thrust':'Gambe','Hip Abduction':'Gambe','Hip Adduction':'Gambe',
  "Captain's Chair Leg Raise":'Addominali',"Captain's Chair Knee Raise":'Addominali',
  'Crunches':'Addominali','Decline Crunch':'Addominali','Decline Sit-up':'Addominali','Plank':'Addominali',
  'Wrist Curl':'Avambracci','Reverse Wrist Curl':'Avambracci','Cable Wrist Curl':'Avambracci',
  'Dumbbell Reverse Wrist Curl':'Avambracci',
  'Football':'Altro','Skiers':'Altro',
};

const EXERCISE_NAME_IT = {
  'Bench Press': 'Panca piana',
  'Dumbbell Bench Press': 'Panca piana con manubri',
  'Incline Dumbbell Bench Press': 'Panca inclinata con manubri',
  'Incline Dumbbell Fly': 'Croci inclinate con manubri',
  'Cable Fly': 'Croci ai cavi',
  'High to Low Cable Fly': 'Croci ai cavi alto-basso',
  'Chest Press': 'Chest press (macchina)',
  'Smith Machine Bench Press': 'Panca piana al multipower',
  'Smith Machine Incline Bench Press': 'Panca inclinata al multipower',
  'Dips': 'Dip alle parallele',
  'Diamond Push Ups': 'Piegamenti a diamante',
  'Supine Bench Press': 'Panca presa supina',
  'Seated Cable Row': 'Rematore al cavo da seduto',
  'Dumbbell Row': 'Rematore con manubrio',
  'Chest Supported Dumbbell Row': 'Rematore con manubri su panca inclinata',
  'Lat Pulldown': 'Lat machine',
  'One Arm Lat Pulldown': 'Lat machine a un braccio',
  'Machine Row': 'Rematore alla macchina',
  'Bent Over Row': 'Rematore con bilanciere',
  'Neutral Grip Pull Ups': 'Trazioni presa neutra',
  'Pull Ups': 'Trazioni alla sbarra',
  'Chin Ups': 'Trazioni presa supina',
  'Dead Hang': 'Sospensione alla sbarra',
  'Back Extension': 'Iperestensioni lombari',
  'Deadlift': 'Stacco da terra',
  'Face Pull': 'Face pull',
  'Cable Reverse Fly': 'Aperture inverse ai cavi',
  'Dumbbell Reverse Fly': 'Aperture inverse con manubri',
  'One Arm Cable Reverse Fly': 'Apertura inversa al cavo a un braccio',
  'Machine Shoulder Press': 'Lento avanti alla macchina',
  'Seated Dumbbell Shoulder Press': 'Lento avanti con manubri da seduto',
  'Military Press': 'Military press',
  'Dumbbell Lateral Raise': 'Alzate laterali con manubri',
  'Cable Lateral Raise': 'Alzate laterali ai cavi',
  'Machine Lateral Raise': 'Alzate laterali alla macchina',
  'Lu Raise': 'Lu raise',
  'Dumbbell Shrug': 'Scrollate con manubri',
  'Cable Shrug': 'Scrollate al cavo',
  'Machine Shrug': 'Scrollate alla macchina',
  'Smith Machine Shrug': 'Scrollate al multipower',
  '60° Shrugs': 'Scrollate a 60°',
  'Chest Supported Dumbbell Shrug': 'Scrollate con manubri su panca inclinata',
  'EZ Bar Curl': 'Curl con bilanciere EZ',
  'EZ Bar Preacher Curl': 'Curl al panchetto con bilanciere EZ',
  'Hammer Curl': 'Curl a martello',
  'Incline Dumbbell Curl': 'Curl su panca inclinata',
  'Cable Hammer Curl': 'Curl a martello al cavo',
  'Dumbbell Curl': 'Curl con manubri',
  'Preacher Curl': 'Curl al panchetto Scott',
  'Preacher Hammer Curl': 'Curl a martello al panchetto Scott',
  'Cross Body Hammer Curl': 'Curl a martello incrociato',
  'Incline Hammer Curl': 'Curl a martello su panca inclinata',
  'Dumbbell Reverse Curl': 'Curl inverso con manubri',
  'Tricep Pushdown': 'Push down ai cavi',
  'Seated Dumbbell Tricep Extension': 'Estensioni tricipiti con manubrio da seduto',
  'Cable Overhead Tricep Extension': 'Estensioni tricipiti ai cavi sopra la testa',
  'EZ Bar Lying Tricep Extension': 'French press con bilanciere EZ',
  'JM Press': 'JM press',
  'Tricep Extension': 'Estensioni tricipiti',
  'Squat': 'Squat',
  'Smith Machine Squat': 'Squat al multipower',
  'Hack Squat': 'Hack squat',
  'Leg Extension': 'Leg extension',
  'Seated Leg Curl': 'Leg curl da seduto',
  'Hip Thrust': 'Hip thrust',
  'Hip Abduction': 'Abduzione anca (macchina)',
  'Hip Adduction': 'Adduzione anca (macchina)',
  'Captain\'s Chair Leg Raise': 'Sollevamento gambe alla sedia romana',
  'Captain\'s Chair Knee Raise': 'Sollevamento ginocchia alla sedia romana',
  'Crunches': 'Crunch',
  'Decline Crunch': 'Crunch su panca declinata',
  'Decline Sit-up': 'Sit-up su panca declinata',
  'Plank': 'Plank',
  'Wrist Curl': 'Curl polsi',
  'Reverse Wrist Curl': 'Curl polsi inverso',
  'Cable Wrist Curl': 'Curl polsi al cavo',
  'Dumbbell Reverse Wrist Curl': 'Curl polsi inverso con manubri',
  'Football': 'Calcio',
  'Skiers': 'Sci',
};

function translateExercise(name, lang) {
  if (lang === 'en') return name;
  return EXERCISE_NAME_IT[name] || name;
}

const GROUP_NAME_EN = {
  Petto: 'Chest', Schiena: 'Back', Spalle: 'Shoulders', Bicipiti: 'Biceps',
  Tricipiti: 'Triceps', Gambe: 'Legs', Addominali: 'Abs', Avambracci: 'Forearms', Altro: 'Other',
};
function translateGroup(name, lang) {
  if (lang === 'it') return name;
  return GROUP_NAME_EN[name] || name;
}

function guessGroup(exerciseName) {
  return EXERCISE_TO_GROUP[exerciseName] || 'Altro';
}


function fmtDate(d) {
  const [y,m,day] = d.split('-');
  return `${day}/${m}/${y.slice(2)}`;
}

function toTs(dateStr) {
  return new Date(dateStr).getTime();
}

// Formatta un numero in stile italiano: virgola come separatore decimale, niente ",0" superfluo (75.0 -> "75", 77.2 -> "77,2")
function fmtKg(n) {
  const rounded = Math.round(n * 10) / 10;
  if (Number.isInteger(rounded)) return String(rounded);
  return rounded.toFixed(1).replace('.', ',');
}

function fmtTick(ts) {
  const d = new Date(ts);
  const day = String(d.getDate()).padStart(2,'0');
  const month = String(d.getMonth()+1).padStart(2,'0');
  const year = String(d.getFullYear()).slice(2);
  return `${day}/${month}/${year}`;
}

function parseDurationIrrelevant() {} // placeholder, non serve qui

// Converte le righe grezze di un CSV Liftoff (con header Date,Duration,Workout Name,Exercise Name,Set Order,Weight,Reps,...)
// in righe [date, exercise, group, weight_kg, reps]. Assume peso in libbre come nell'export originale.
function csvRowsToRaw(rows) {
  const out = [];
  for (const r of rows) {
    const dateRaw = r['Date'];
    const exercise = r['Exercise Name'];
    const weight = parseFloat(r['Weight']);
    const reps = parseInt(r['Reps'], 10);
    if (!dateRaw || !exercise || isNaN(weight) || isNaN(reps)) continue;
    const date = dateRaw.slice(0, 10);
    const weightKg = Math.round(weight * LB_TO_KG * 10) / 10;
    out.push([date, exercise, guessGroup(exercise), weightKg, reps]);
  }
  return out;
}

// Converte un peso nell'unità indicata dalla riga stessa (colonna "Weight Unit" di Strong) in kg.
// A differenza di Liftoff, Strong indica riga per riga se il peso è già in kg o in lb, quindi
// niente conversione "a occhio": rispettiamo esattamente quello che dice l'export.
function toKgFromUnit(weight, unit) {
  const u = (unit || '').toString().trim().toLowerCase();
  if (u === 'kg') return weight;
  // lb, lbs, o assente: assumiamo libbre come da export standard Strong quando manca l'unità
  return weight * LB_TO_KG;
}

// Converte le righe di un export Strong in righe [date, exercise, group, weight_kg, reps].
// Formato reale Strong: "Date","Workout Name","Exercise Name","Set Order","Weight","Weight Unit",
// "Reps","RPE","Distance","Distance Unit","Seconds","Notes","Workout Notes","Workout Duration".
// Il separatore CSV varia tra versioni (',' o ';'): la rilevazione è demandata a Papa.parse
// (delimiter: "" per l'auto-detect), qui riceviamo già righe oggetto già parsate correttamente.
function strongRowsToRaw(rows) {
  const out = [];
  for (const r of rows) {
    const dateRaw = r['Date'];
    const exercise = r['Exercise Name'];
    const weight = parseFloat(r['Weight']);
    const reps = parseInt(r['Reps'], 10);
    if (!dateRaw || !exercise || isNaN(weight) || isNaN(reps)) continue;
    const date = dateRaw.slice(0, 10);
    const weightKg = Math.round(toKgFromUnit(weight, r['Weight Unit']) * 10) / 10;
    out.push([date, exercise, guessGroup(exercise), weightKg, reps]);
  }
  return out;
}

// Converte le righe di un export Hevy in righe [date, exercise, group, weight_kg, reps].
// Formato reale Hevy: "title","start_time","end_time","description","exercise_title","superset_id",
// "exercise_notes","set_index","set_type","weight_kg","reps","distance_km","duration_seconds","rpe".
// Hevy esporta il peso già in kg (weight_kg): a differenza di Liftoff/Strong non serve alcuna conversione.
// La data è dentro start_time (es. "8 Jan 2024, 16:00"): usiamo new Date() e teniamo solo YYYY-MM-DD.
function hevyRowsToRaw(rows) {
  const out = [];
  for (const r of rows) {
    const startTime = r['start_time'];
    const exercise = r['exercise_title'];
    const weight = parseFloat(r['weight_kg']);
    const reps = parseInt(r['reps'], 10);
    if (!startTime || !exercise || isNaN(weight) || isNaN(reps)) continue;
    const parsedDate = new Date(startTime);
    if (isNaN(parsedDate.getTime())) continue;
    const date = parsedDate.toISOString().slice(0, 10);
    const weightKg = Math.round(weight * 10) / 10;
    out.push([date, exercise, guessGroup(exercise), weightKg, reps]);
  }
  return out;
}

// Parser "best effort" per Jefit: i CSV variano molto tra versioni dell'app, quindi cerchiamo
// colonne con nomi simili case-insensitive invece di assumere intestazioni fisse. Se non troviamo
// i campi essenziali (data/esercizio/peso/reps) restituiamo un errore chiaro invece di importare
// silenziosamente dati vuoti o sbagliati — meglio bloccare che sporcare lo storico dell'utente.
function findColumnCaseInsensitive(headerKeys, candidates) {
  const lowerMap = {};
  headerKeys.forEach(k => { lowerMap[k.toLowerCase().trim()] = k; });
  for (const cand of candidates) {
    if (lowerMap[cand]) return lowerMap[cand];
    // match parziale: es. "reps" dentro "repetitions", o "lbs" dentro "weight (lbs)"
    const partial = headerKeys.find(k => k.toLowerCase().includes(cand));
    if (partial) return partial;
  }
  return null;
}

function jefitRowsToRaw(rows) {
  if (!rows.length) throw new Error('Il file è vuoto.');
  const headerKeys = Object.keys(rows[0]);
  const dateCol = findColumnCaseInsensitive(headerKeys, ['date', 'day']);
  const exerciseCol = findColumnCaseInsensitive(headerKeys, ['exercise name', 'exercise']);
  const weightCol = findColumnCaseInsensitive(headerKeys, ['weight', 'lbs', 'kg']);
  const repsCol = findColumnCaseInsensitive(headerKeys, ['reps', 'repetitions', 'rep']);
  // log chiaro in console di quali colonne sono state individuate, utile per debug su export "strani"
  console.log('[Jefit import] colonne individuate:', { dateCol, exerciseCol, weightCol, repsCol });
  if (!dateCol || !exerciseCol || !weightCol || !repsCol) {
    const missing = [
      !dateCol && 'data', !exerciseCol && 'esercizio', !weightCol && 'peso', !repsCol && 'reps',
    ].filter(Boolean).join(', ');
    throw new Error(`Impossibile riconoscere le colonne necessarie nel file Jefit (mancanti: ${missing}). Prova con "Altro formato CSV" per mappare le colonne manualmente.`);
  }
  // se la colonna peso ha nel nome "kg" assumiamo kg, altrimenti libbre (default export Jefit è in lb)
  const weightIsKg = weightCol.toLowerCase().includes('kg');
  const out = [];
  for (const r of rows) {
    const dateRaw = r[dateCol];
    const exercise = r[exerciseCol];
    const weight = parseFloat(r[weightCol]);
    const reps = parseInt(r[repsCol], 10);
    if (!dateRaw || !exercise || isNaN(weight) || isNaN(reps)) continue;
    const date = String(dateRaw).slice(0, 10);
    const weightKg = Math.round((weightIsKg ? weight : weight * LB_TO_KG) * 10) / 10;
    out.push([date, exercise, guessGroup(exercise), weightKg, reps]);
  }
  return out;
}

// Applica una mappatura manuale di colonne (scelta dall'utente per "Altro formato CSV") a tutte le righe.
// mapping = { date, exercise, weight, reps, weightUnit } dove ognuno è il nome reale della colonna nel file
// (weightUnit è opzionale: se assente si assume l'unità passata in defaultWeightUnit).
function mappedRowsToRaw(rows, mapping, defaultWeightUnit) {
  const out = [];
  for (const r of rows) {
    const dateRaw = r[mapping.date];
    const exercise = r[mapping.exercise];
    const weight = parseFloat(r[mapping.weight]);
    const reps = parseInt(r[mapping.reps], 10);
    if (!dateRaw || !exercise || isNaN(weight) || isNaN(reps)) continue;
    const date = String(dateRaw).slice(0, 10);
    const rowUnit = mapping.weightUnit ? r[mapping.weightUnit] : defaultWeightUnit;
    const weightKg = Math.round(toKgFromUnit(weight, rowUnit) * 10) / 10;
    out.push([date, exercise, guessGroup(exercise), weightKg, reps]);
  }
  return out;
}

// Elenco delle app sorgente supportate per l'import CSV, usato dal selettore mostrato prima
// della scelta del file sia nel primo upload sia nell'aggiornamento export.
const IMPORT_APPS = [
  { key: 'liftoff', labelKey: 'importAppLiftoff' },
  { key: 'strong', labelKey: 'importAppStrong' },
  { key: 'hevy', labelKey: 'importAppHevy' },
  { key: 'jefit', labelKey: 'importAppJefit' },
  { key: 'other', labelKey: 'importAppOther' },
];

// Selettore "app di provenienza": piccolo dropdown mostrato prima della scelta del file,
// riusato sia dal primo upload sia dall'aggiornamento export dentro WorkoutBodyExplorer.
function ImportAppSelector({ value, onChange, langApp }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <label style={{ fontSize: 10.5, color: '#9694B0', display: 'block', marginBottom: 4 }}>{t(langApp, 'importAppLabel')}</label>
      <select value={value} onChange={e => onChange(e.target.value)} style={{
        width: '100%', padding: '9px 12px', borderRadius: 8,
        background: '#1B1930', border: '1px solid #4A4870', color: '#EDEBFF',
        fontSize: 12.5, fontFamily: '"Inter", sans-serif',
      }}>
        {IMPORT_APPS.map(a => (
          <option key={a.key} value={a.key}>{t(langApp, a.labelKey)}</option>
        ))}
      </select>
    </div>
  );
}

// Analizza un file CSV già parsato da Papa.parse in base all'app scelta, restituendo le righe
// nel formato interno comune. Per 'other' non produce righe direttamente: segnala che serve
// una mappatura manuale (gestita da ImportMappingModal) restituendo needsMapping=true.
function rowsForImportApp(appKey, parsedRows) {
  switch (appKey) {
    case 'liftoff': return { rows: csvRowsToRaw(parsedRows), needsMapping: false };
    case 'strong': return { rows: strongRowsToRaw(parsedRows), needsMapping: false };
    case 'hevy': return { rows: hevyRowsToRaw(parsedRows), needsMapping: false };
    case 'jefit': return { rows: jefitRowsToRaw(parsedRows), needsMapping: false };
    case 'other': return { rows: [], needsMapping: true };
    default: return { rows: csvRowsToRaw(parsedRows), needsMapping: false };
  }
}

// Opzioni di Papa.parse per ciascuna app: Strong in particolare varia il separatore tra versioni
// (',' o ';'), quindi lasciamo che papaparse lo rilevi da solo (delimiter: "" attiva l'auto-detect).
function papaOptionsForImportApp(appKey) {
  if (appKey === 'strong') return { header: true, skipEmptyLines: true, delimiter: '' };
  return { header: true, skipEmptyLines: true };
}

// Modale di mappatura manuale colonne per "Altro formato CSV": mostra le intestazioni reali del file
// (lette con Papa.parse preview:1) e lascia scegliere quale colonna corrisponde a ciascun campo richiesto.
function ImportMappingModal({ headers, onConfirm, onCancel, langApp, defaultWeightUnit }) {
  const [dateCol, setDateCol] = useState('');
  const [exerciseCol, setExerciseCol] = useState('');
  const [weightCol, setWeightCol] = useState('');
  const [repsCol, setRepsCol] = useState('');
  const [weightUnitCol, setWeightUnitCol] = useState('');
  const [error, setError] = useState(null);

  function handleConfirm() {
    if (!dateCol || !exerciseCol || !weightCol || !repsCol) {
      setError(t(langApp, 'importMappingIncomplete'));
      return;
    }
    onConfirm({ date: dateCol, exercise: exerciseCol, weight: weightCol, reps: repsCol, weightUnit: weightUnitCol || null }, defaultWeightUnit);
  }

  const selectStyle = {
    width: '100%', padding: '8px 10px', borderRadius: 8, marginTop: 4, marginBottom: 10,
    background: '#1B1930', border: '1px solid #4A4870', color: '#EDEBFF',
    fontSize: 12.5, fontFamily: '"Inter", sans-serif',
  };

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 50,
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16,
    }}>
      <div className="panel-anim" style={{
        width: '100%', maxWidth: 380, maxHeight: '85vh', overflowY: 'auto', scrollBehavior: 'smooth',
        background: '#252341', border: '1px solid #4A4870', borderRadius: 14, padding: 16,
      }}>
        <div style={{ fontFamily: '"Oswald", sans-serif', fontSize: 16, fontWeight: 600, marginBottom: 6, color: '#EDEBFF' }}>
          {t(langApp, 'importMappingTitle')}
        </div>
        <div style={{ fontSize: 12, color: '#9694B0', marginBottom: 14, lineHeight: 1.5 }}>
          {t(langApp, 'importMappingIntro')}
        </div>

        <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'importMappingDate')}</label>
        <select value={dateCol} onChange={e => setDateCol(e.target.value)} style={selectStyle}>
          <option value="">—</option>
          {headers.map(h => <option key={h} value={h}>{h}</option>)}
        </select>

        <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'importMappingExercise')}</label>
        <select value={exerciseCol} onChange={e => setExerciseCol(e.target.value)} style={selectStyle}>
          <option value="">—</option>
          {headers.map(h => <option key={h} value={h}>{h}</option>)}
        </select>

        <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'importMappingWeight')}</label>
        <select value={weightCol} onChange={e => setWeightCol(e.target.value)} style={selectStyle}>
          <option value="">—</option>
          {headers.map(h => <option key={h} value={h}>{h}</option>)}
        </select>

        <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'importMappingReps')}</label>
        <select value={repsCol} onChange={e => setRepsCol(e.target.value)} style={selectStyle}>
          <option value="">—</option>
          {headers.map(h => <option key={h} value={h}>{h}</option>)}
        </select>

        <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'importMappingWeightUnit')}</label>
        <select value={weightUnitCol} onChange={e => setWeightUnitCol(e.target.value)} style={selectStyle}>
          <option value="">{t(langApp, 'importMappingNone')}</option>
          {headers.map(h => <option key={h} value={h}>{h}</option>)}
        </select>

        {error && <div style={{ color: '#e08a8a', fontSize: 12, marginBottom: 10 }}>{error}</div>}

        <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
          <button onClick={onCancel} style={{
            flex: 1, padding: '9px 14px', borderRadius: 10, border: '1px solid #4A4870',
            background: '#1B1930', color: '#D4D2E8', fontSize: 12.5, fontFamily: '"Inter", sans-serif', cursor: 'pointer',
          }}>{t(langApp, 'close')}</button>
          <button onClick={handleConfirm} style={{
            flex: 1, padding: '9px 14px', borderRadius: 10, border: 'none',
            background: '#5ADECD', color: '#1B1930', fontWeight: 600, fontSize: 12.5, fontFamily: '"Inter", sans-serif', cursor: 'pointer',
          }}>{t(langApp, 'importMappingConfirm')}</button>
        </div>
      </div>
    </div>
  );
}

// Silhouette semplificata in stile "bodygraph": fronte/retro, zone colorabili.
function BodyMap({ selected, onSelect, view, setView, availableGroups }) {
  const isAvail = (g) => availableGroups.has(g);
  const fillFor = (g) => selected === g ? GROUP_COLOR[g] : (isAvail(g) ? '#2b2823' : '#1c1915');
  const clickable = (g) => isAvail(g)
    ? { cursor: 'pointer', transition: 'fill 0.15s ease, opacity 0.15s ease' }
    : { cursor: 'default', opacity: 0.35, transition: 'fill 0.15s ease, opacity 0.15s ease' };
  const handle = (g) => isAvail(g) ? () => onSelect(g) : undefined;

  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:12 }}>
      <div style={{ display:'flex', gap:8, background:'#1a1a1a', padding:4, borderRadius:8 }}>
        <button onClick={()=>setView('front')} style={{
          padding:'6px 16px', borderRadius:6, border:'none', cursor:'pointer',
          fontFamily:'"Oswald", sans-serif', fontSize:12, letterSpacing:1, textTransform:'uppercase',
          background: view==='front' ? '#5ADECD' : 'transparent',
          color: view==='front' ? '#1B1930' : '#9694B0',
          transition: 'background 0.15s ease, color 0.15s ease',
        }}>Fronte</button>
        <button onClick={()=>setView('back')} style={{
          padding:'6px 16px', borderRadius:6, border:'none', cursor:'pointer',
          fontFamily:'"Oswald", sans-serif', fontSize:12, letterSpacing:1, textTransform:'uppercase',
          background: view==='back' ? '#5ADECD' : 'transparent',
          color: view==='back' ? '#1B1930' : '#9694B0',
          transition: 'background 0.15s ease, color 0.15s ease',
        }}>Retro</button>
      </div>

      <svg className="bodymap-svg" viewBox="0 0 200 320" width="180" height="288" style={{ maxWidth: '100%', maxHeight: '60vh', height: 'auto' }}>
        {/* testa: non corrisponde a nessun gruppo muscolare allenabile, resta sempre semi-trasparente e non cliccabile */}
        <circle cx="100" cy="35" r="18" fill="#2b2823" stroke="#4A4870" strokeWidth="1" opacity="0.35"/>
        {/* collo */}
        <rect x="93" y="50" width="14" height="10" fill="#2b2823" opacity="0.35"/>

        {view === 'front' ? (
          <>
            {/* torso/petto */}
            <path d="M 65 62 Q 100 55 135 62 L 140 130 Q 100 140 60 130 Z"
              fill={fillFor('Petto')} stroke="#4A4870" strokeWidth="1" style={clickable('Petto')}
              onClick={handle('Petto')} />
            {/* spalle */}
            <ellipse cx="58" cy="70" rx="14" ry="12" fill={fillFor('Spalle')} stroke="#4A4870" strokeWidth="1" style={clickable('Spalle')} onClick={handle('Spalle')} />
            <ellipse cx="142" cy="70" rx="14" ry="12" fill={fillFor('Spalle')} stroke="#4A4870" strokeWidth="1" style={clickable('Spalle')} onClick={handle('Spalle')} />
            {/* bicipiti (bracci sup) */}
            <rect x="42" y="82" width="16" height="45" rx="8" fill={fillFor('Bicipiti')} stroke="#4A4870" strokeWidth="1" style={clickable('Bicipiti')} onClick={handle('Bicipiti')} />
            <rect x="142" y="82" width="16" height="45" rx="8" fill={fillFor('Bicipiti')} stroke="#4A4870" strokeWidth="1" style={clickable('Bicipiti')} onClick={handle('Bicipiti')} />
            {/* avambracci */}
            <rect x="40" y="127" width="14" height="42" rx="7" fill={fillFor('Avambracci')} stroke="#4A4870" strokeWidth="1" style={clickable('Avambracci')} onClick={handle('Avambracci')} />
            <rect x="146" y="127" width="14" height="42" rx="7" fill={fillFor('Avambracci')} stroke="#4A4870" strokeWidth="1" style={clickable('Avambracci')} onClick={handle('Avambracci')} />
            {/* addominali */}
            <rect x="75" y="130" width="50" height="45" rx="6" fill={fillFor('Addominali')} stroke="#4A4870" strokeWidth="1" style={clickable('Addominali')} onClick={handle('Addominali')} />
            {/* gambe */}
            <rect x="72" y="178" width="24" height="110" rx="10" fill={fillFor('Gambe')} stroke="#4A4870" strokeWidth="1" style={clickable('Gambe')} onClick={handle('Gambe')} />
            <rect x="104" y="178" width="24" height="110" rx="10" fill={fillFor('Gambe')} stroke="#4A4870" strokeWidth="1" style={clickable('Gambe')} onClick={handle('Gambe')} />
          </>
        ) : (
          <>
            {/* schiena */}
            <path d="M 65 62 Q 100 55 135 62 L 140 175 Q 100 185 60 175 Z"
              fill={fillFor('Schiena')} stroke="#4A4870" strokeWidth="1" style={clickable('Schiena')}
              onClick={handle('Schiena')} />
            <ellipse cx="58" cy="70" rx="14" ry="12" fill={fillFor('Spalle')} stroke="#4A4870" strokeWidth="1" style={clickable('Spalle')} onClick={handle('Spalle')} />
            <ellipse cx="142" cy="70" rx="14" ry="12" fill={fillFor('Spalle')} stroke="#4A4870" strokeWidth="1" style={clickable('Spalle')} onClick={handle('Spalle')} />
            <rect x="42" y="82" width="16" height="45" rx="8" fill={fillFor('Tricipiti')} stroke="#4A4870" strokeWidth="1" style={clickable('Tricipiti')} onClick={handle('Tricipiti')} />
            <rect x="142" y="82" width="16" height="45" rx="8" fill={fillFor('Tricipiti')} stroke="#4A4870" strokeWidth="1" style={clickable('Tricipiti')} onClick={handle('Tricipiti')} />
            <rect x="40" y="127" width="14" height="42" rx="7" fill={fillFor('Avambracci')} stroke="#4A4870" strokeWidth="1" style={clickable('Avambracci')} onClick={handle('Avambracci')} />
            <rect x="146" y="127" width="14" height="42" rx="7" fill={fillFor('Avambracci')} stroke="#4A4870" strokeWidth="1" style={clickable('Avambracci')} onClick={handle('Avambracci')} />
            <rect x="72" y="175" width="24" height="113" rx="10" fill={fillFor('Gambe')} stroke="#4A4870" strokeWidth="1" style={clickable('Gambe')} onClick={handle('Gambe')} />
            <rect x="104" y="175" width="24" height="113" rx="10" fill={fillFor('Gambe')} stroke="#4A4870" strokeWidth="1" style={clickable('Gambe')} onClick={handle('Gambe')} />
          </>
        )}
      </svg>
    </div>
  );
}

// Grafico stile "trading": pan continuo trascinando, zoom con rotella/pinch, e scaletta di
// intervalli rapidi (1M/3M/6M/1A/Tutto). Sostituisce il vecchio Brush a indici discreti,
// che risultava meccanico e scattoso quando si trascinavano gli estremi verso i bordi.
function TradingStyleChart({ mergedChartData, compareExercises, colorForExercise, firstTs, todayTs, newYearTicks, viewDomain, setViewDomain, weightUnit, langExercise, langApp }) {
  const containerRef = React.useRef(null);
  const dragState = React.useRef(null); // { startX, startDomain } durante un pan
  const pinchState = React.useRef(null); // distanza iniziale tra due dita durante un pinch
  const MIN_SPAN_MS = 1000 * 60 * 60 * 24 * 3; // non zoomare oltre ~3 giorni di ampiezza
  // Timestamp del punto "ancorato" con un click: la linea verticale e il tooltip restano fissi lì
  // finché non si clicca su un altro punto (o si clicca fuori), invece di seguire il trascinamento
  // del dito come faceva il cursore automatico di Recharts — è il comportamento richiesto.
  const [selectedTs, setSelectedTs] = useState(null);

  // riga dati completa corrispondente al punto selezionato (o null se selectedTs non combacia con
  // nessun punto reale, es. dopo un cambio di dataset): unica fonte di verità per Tooltip+ReferenceLine
  const selectedPointPayload = useMemo(() => {
    if (selectedTs == null) return null;
    return mergedChartData.find(d => d.ts === selectedTs) || null;
  }, [selectedTs, mergedChartData]);

  // trasforma il punto selezionato nel formato {name, value, payload} atteso da Tooltip.payload,
  // una entry per ogni esercizio in confronto che ha un valore in quel punto
  const selectedTooltipPayload = useMemo(() => {
    if (!selectedPointPayload) return [];
    return compareExercises
      .filter(ex => selectedPointPayload[ex] != null)
      .map(ex => ({ name: ex, value: selectedPointPayload[ex], payload: selectedPointPayload }));
  }, [selectedPointPayload, compareExercises]);

  const fullSpan = Math.max(todayTs - firstTs, MIN_SPAN_MS);
  const domain = viewDomain || [firstTs, todayTs];

  function clampDomain([start, end]) {
    let span = end - start;
    if (span < MIN_SPAN_MS) span = MIN_SPAN_MS;
    if (span > fullSpan) span = fullSpan;
    let newStart = start;
    let newEnd = newStart + span;
    // non lasciare che la vista esca troppo dai dati disponibili (con un piccolo margine)
    const margin = span * 0.15;
    if (newStart < firstTs - margin) { newStart = firstTs - margin; newEnd = newStart + span; }
    if (newEnd > todayTs + margin) { newEnd = todayTs + margin; newStart = newEnd - span; }
    return [newStart, newEnd];
  }

  function applyPreset(months) {
    if (months === null) { setViewDomain(null); return; }
    const end = todayTs;
    const start = new Date(end);
    start.setMonth(start.getMonth() - months);
    // se il preset copre più storico di quanto disponibile, mostra semplicemente tutto lo storico
    const clampedStart = Math.max(start.getTime(), firstTs);
    setViewDomain([clampedStart, end]);
  }

  function zoomBy(factor, pivotRatio = 0.5) {
    const [start, end] = domain;
    const span = end - start;
    const pivot = start + span * pivotRatio;
    const newSpan = span * factor;
    const newStart = pivot - (pivot - start) * factor;
    const newEnd = newStart + newSpan;
    setViewDomain(clampDomain([newStart, newEnd]));
  }

  function panBy(deltaRatio) {
    const [start, end] = domain;
    const span = end - start;
    const shift = span * deltaRatio;
    setViewDomain(clampDomain([start + shift, end + shift]));
  }

  function handleWheel(e) {
    // Sul trackpad (Mac e la maggior parte dei driver Windows Precision), il browser distingue
    // da solo i due gesti: un pinch a due dita arriva come evento "wheel" con ctrlKey impostato
    // automaticamente a true (indipendentemente dal fatto che l'utente prema davvero Ctrl); uno
    // scroll normale a due dita arriva invece con ctrlKey false e deltaX/deltaY proporzionali alla
    // direzione dello scorrimento. Su un mouse con rotellina c'è solo deltaY e nessun ctrlKey: in
    // quel caso manteniamo il vecchio comportamento (rotellina = zoom), dato che il mouse non ha
    // un gesto di pan a due dita.
    if (e.ctrlKey) {
      e.preventDefault();
      // pinch-zoom da trackpad: fattore proporzionale al deltaY ma clampato, molto più dolce
      // del precedente fattore fisso 1.15 (che rendeva il pinch troppo sensibile su desktop).
      const clampedDelta = Math.max(-40, Math.min(40, e.deltaY));
      const smoothFactor = 1 + (clampedDelta / 40) * 0.12;
      const rect = containerRef.current.getBoundingClientRect();
      const pivotRatio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
      zoomBy(smoothFactor, pivotRatio);
      return;
    }
    // scroll a due dita (o rotellina): se il movimento orizzontale prevale, pannare sinistra/destra;
    // altrimenti (movimento verticale prevalente) lasciamo che sia il browser a gestirlo come scroll
    // della pagina, così scorrere su/giù con due dita quando il cursore è sopra il grafico non
    // resta "intrappolato" qui dentro invece di far scorrere la pagina.
    if (Math.abs(e.deltaX) > Math.abs(e.deltaY) && e.deltaX !== 0) {
      e.preventDefault();
      const rect = containerRef.current.getBoundingClientRect();
      panBy(e.deltaX / Math.max(rect.width, 1));
    }
  }

  function handlePointerDown(e) {
    if (e.touches && e.touches.length === 2) {
      pinchState.current = {
        dist: Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY),
        domain,
      };
      dragState.current = null;
      return;
    }
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    dragState.current = { startX: clientX, startDomain: domain };
  }

  function handlePointerMove(e) {
    if (e.touches && e.touches.length === 2 && pinchState.current) {
      const dist = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      const factor = pinchState.current.dist / Math.max(dist, 1);
      const [start, end] = pinchState.current.domain;
      const span = end - start;
      const center = start + span / 2;
      const newSpan = span * factor;
      setViewDomain(clampDomain([center - newSpan / 2, center + newSpan / 2]));
      return;
    }
    if (!dragState.current) return;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const rect = containerRef.current.getBoundingClientRect();
    const [start, end] = dragState.current.startDomain;
    const span = end - start;
    const deltaPx = clientX - dragState.current.startX;
    const deltaTs = -(deltaPx / Math.max(rect.width, 1)) * span;
    setViewDomain(clampDomain([start + deltaTs, end + deltaTs]));
  }

  function handlePointerUp() {
    dragState.current = null;
    pinchState.current = null;
  }

  const presets = [
    { key: 'range1m', months: 1 },
    { key: 'range3m', months: 3 },
    { key: 'range6m', months: 6 },
    { key: 'range1y', months: 12 },
    { key: 'rangeAll', months: null },
  ];

  return (
    <>
      <div style={{ display: 'flex', gap: 6, marginBottom: 8, flexWrap: 'wrap' }}>
        {presets.map(p => (
          <button key={p.key} onClick={() => applyPreset(p.months)} style={{
            padding: '5px 11px', borderRadius: 8, border: '1px solid #4A4870',
            background: (p.months === null ? !viewDomain : false) ? '#5ADECD' : '#1B1930',
            color: (p.months === null ? !viewDomain : false) ? '#1B1930' : '#D4D2E8',
            fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: '"Inter", sans-serif',
            transition: 'background 0.15s ease, color 0.15s ease',
          }}>
            {t(langApp, p.key)}
          </button>
        ))}
      </div>

      <div
        ref={containerRef}
        className="trading-chart-container"
        style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: '12px 12px 8px 0', height: 'clamp(220px, 45vh, 380px)', touchAction: 'none', cursor: 'grab', userSelect: 'none' }}
        onWheel={handleWheel}
        onMouseDown={handlePointerDown}
        onMouseMove={handlePointerMove}
        onMouseUp={handlePointerUp}
        onMouseLeave={handlePointerUp}
        onTouchStart={handlePointerDown}
        onTouchMove={handlePointerMove}
        onTouchEnd={handlePointerUp}
      >
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={mergedChartData} margin={{ top: 5, right: 12, left: 0, bottom: 5 }}
            onClick={(chartState) => {
              // clic sull'area del grafico: ancora la linea/tooltip al punto più vicino cliccato
              // (più facile da colpire su mobile rispetto al singolo pallino). Un secondo clic sullo
              // stesso punto lo deseleziona, così si può "spegnere" la linea senza uscire dal grafico.
              if (chartState && chartState.activeLabel != null) {
                const ts = Number(chartState.activeLabel);
                setSelectedTs(prev => (prev === ts ? null : ts));
              }
            }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#3A3856" />
            <XAxis
              dataKey="ts"
              type="number"
              scale="time"
              domain={domain}
              allowDataOverflow={true}
              tickFormatter={fmtTick}
              stroke="#6E6C8E" fontSize={9.5} tick={{fill:'#9694B0'}}
              interval="preserveStartEnd"
              minTickGap={40}
            />
            <YAxis stroke="#6E6C8E" fontSize={9.5} tick={{fill:'#9694B0'}} width={38} domain={['auto', 'auto']} allowDataOverflow={false} />
            {newYearTicks.map(ts => (
              <ReferenceLine key={ts} x={ts} stroke="#6E6C8E" strokeDasharray="4 4" strokeWidth={1}
                label={{ value: String(new Date(ts).getFullYear()), position: 'top', fill: '#6E6C8E', fontSize: 9.5 }} />
            ))}
            {/* linea verticale ancorata al punto cliccato: NON si muove durante lo scorrimento/pan,
                appare solo quando si clicca su un punto e resta lì finché non se ne clicca un altro.
                Il Tooltip è controllato esplicitamente da selectedTs (active/payload/label), invece di
                affidarci solo allo stato interno di Recharts, così i due restano sempre sincronizzati:
                stessa fonte di verità per "cosa è selezionato". */}
            {selectedTs != null && (
              <ReferenceLine x={selectedTs} stroke="#5ADECD" strokeWidth={1.5} strokeDasharray="3 3" />
            )}
            <Tooltip
              trigger="click"
              active={selectedTs != null && !!selectedPointPayload}
              payload={selectedPointPayload ? selectedTooltipPayload : []}
              label={selectedTs}
              labelFormatter={fmtTick}
              formatter={(v, name, props) => {
                const detail = props.payload[name + '__detail'];
                const hasLoad = props.payload[name + '__hasLoad'];
                const valueLabel = hasLoad ? `${fmtWeight(v, weightUnit)} ${weightUnitLabel(weightUnit)}` : `${Math.round(v)} rip.`;
                return [`${valueLabel}${detail ? ' ('+detail+')' : ''}`, translateExercise(name, langExercise)];
              }}
              contentStyle={{ background: '#252341', border: '1px solid #4A4870', borderRadius: 8, fontSize: 11 }}
              labelStyle={{ color: '#9694B0' }}
              cursor={false}
            />
            {compareExercises.map(ex => (
              <Line key={ex} type="monotone" dataKey={ex} stroke={colorForExercise(ex)} strokeWidth={2.5}
                dot={{ r: 2.5, fill: colorForExercise(ex), style: { cursor: 'pointer' } }} activeDot={{ r: 5 }} connectNulls={true}
                isAnimationActive={false} />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div style={{ fontSize: 10, color: '#6E6C8E', marginTop: 6, textAlign: 'center' }}>
        {t(langApp, 'zoomHint')}
      </div>
    </>
  );
}

// Grafico semplice per serie temporali singole (peso corporeo, circonferenze, ritmo/durata cardio):
// stessa palette/font del resto dell'app, senza il pan/zoom "da trading" di TradingStyleChart perché
// qui c'è una sola linea e i dataset sono tipicamente piccoli — un ResponsiveContainer fisso è più che
// sufficiente e molto più semplice da mantenere.
function SimpleTrendChart({ data, dataKey, color, valueFormatter, langApp }) {
  if (!data || data.length === 0) return null;
  return (
    <div style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: '12px 12px 8px 0', height: 240 }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 5, right: 12, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#3A3856" />
          <XAxis
            dataKey="ts"
            type="number"
            scale="time"
            domain={['dataMin', 'dataMax']}
            tickFormatter={fmtTick}
            stroke="#6E6C8E" fontSize={9.5} tick={{fill:'#9694B0'}}
            interval="preserveStartEnd"
            minTickGap={40}
          />
          <YAxis stroke="#6E6C8E" fontSize={9.5} tick={{fill:'#9694B0'}} width={38} domain={['auto', 'auto']} />
          <Tooltip
            labelFormatter={fmtTick}
            formatter={(v) => [valueFormatter ? valueFormatter(v) : v, '']}
            contentStyle={{ background: '#252341', border: '1px solid #4A4870', borderRadius: 8, fontSize: 11 }}
            labelStyle={{ color: '#9694B0' }}
          />
          <Line type="monotone" dataKey={dataKey} stroke={color} strokeWidth={2.5}
            dot={{ r: 3, fill: color }} activeDot={{ r: 5 }} connectNulls={true} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// Pannello "Cardio": form di inserimento sessione + lista + grafico ritmo/durata.
// Usa esclusivamente supabase-js su public.cardio_sessions (RLS auth.uid()=user_id), MAI le RPC legacy.
function CardioPanel({ langApp, userId, weightUnit }) {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);

  const [activity, setActivity] = useState('Corsa');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [minutes, setMinutes] = useState('');
  const [seconds, setSeconds] = useState('');
  const [distance, setDistance] = useState(''); // nell'unità di visualizzazione corrente (km o mi)
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState(null);
  const [deletingId, setDeletingId] = useState(null);

  const distUnit = distanceUnitLabel(weightUnit);

  async function loadSessions() {
    setLoading(true);
    setLoadError(null);
    const { data, error } = await supabase
      .from('cardio_sessions')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: false });
    if (error) {
      setLoadError(error.message || t(langApp, 'cardioLoadError'));
    } else {
      setSessions(data || []);
    }
    setLoading(false);
  }

  useEffect(() => {
    if (!userId) return;
    loadSessions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  async function handleSave(e) {
    e.preventDefault();
    setSaveMsg(null);
    const mins = parseFloat(minutes) || 0;
    const secs = parseFloat(seconds) || 0;
    const totalSeconds = Math.round(mins * 60 + secs);
    if (totalSeconds <= 0) {
      setSaveMsg({ ok: false, text: t(langApp, 'cardioDurationInvalid') });
      return;
    }
    // la distanza inserita è nell'unità corrente (km o mi): la convertiamo sempre in metri (km) per il DB
    let distanceMeters = null;
    if (distance.trim() !== '') {
      const distVal = parseFloat(distance);
      if (!isNaN(distVal) && distVal >= 0) {
        const distKm = weightUnit === 'lb' ? distVal / KM_TO_MI : distVal;
        distanceMeters = Math.round(distKm * 1000);
      }
    }
    setSaving(true);
    try {
      const { error } = await supabase.from('cardio_sessions').insert({
        user_id: userId,
        date,
        activity,
        duration_seconds: totalSeconds,
        distance_meters: distanceMeters,
        notes: notes.trim() ? notes.trim().slice(0, 300) : null,
      });
      if (error) throw error;
      setMinutes(''); setSeconds(''); setDistance(''); setNotes('');
      setSaveMsg({ ok: true, text: t(langApp, 'cardioSave') });
      await loadSessions();
    } catch (err) {
      setSaveMsg({ ok: false, text: err.message || t(langApp, 'cardioSaveError') });
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm(t(langApp, 'cardioDeleteConfirm'))) return;
    setDeletingId(id);
    try {
      const { error } = await supabase.from('cardio_sessions').delete().eq('id', id).eq('user_id', userId);
      if (error) throw error;
      setSessions(prev => prev.filter(s => s.id !== id));
    } catch (err) {
      setLoadError(err.message || t(langApp, 'cardioDeleteError'));
    } finally {
      setDeletingId(null);
    }
  }

  // dati per il grafico: pace (min/km) quando c'è distanza, altrimenti durata in minuti.
  // Ordinati crescenti per data (il grafico vuole la serie temporale in ordine, la lista sopra invece decrescente).
  const chartData = useMemo(() => {
    return [...sessions]
      .sort((a, b) => a.date.localeCompare(b.date))
      .map(s => {
        const hasDistance = s.distance_meters != null && s.distance_meters > 0;
        const paceMinPerKm = hasDistance ? (s.duration_seconds / 60) / (s.distance_meters / 1000) : null;
        return {
          ts: toTs(s.date),
          pace: paceMinPerKm,
          durationMin: Math.round((s.duration_seconds / 60) * 10) / 10,
          hasDistance,
        };
      });
  }, [sessions]);

  // se la maggior parte delle sessioni ha distanza, mostriamo il grafico ritmo; altrimenti durata
  const mostlyHaveDistance = chartData.length > 0 && chartData.filter(d => d.hasDistance).length / chartData.length > 0.5;

  const inputStyle = {
    width: '100%', padding: '9px 12px', borderRadius: 8,
    background: '#1B1930', border: '1px solid #4A4870', color: '#EDEBFF',
    fontSize: 12.5, fontFamily: '"Inter", sans-serif',
  };

  return (
    <div style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: 14, marginBottom: 16 }}>
      <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 12 }}>
        {t(langApp, 'cardio')}
      </div>

      <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
        <div style={{ fontSize: 11.5, color: '#D4D2E8', marginBottom: -2 }}>{t(langApp, 'cardioAddSession')}</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <div style={{ flex: 1 }}>
            <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'bodyWeightDate')}</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} style={{ ...inputStyle, marginTop: 4 }} />
          </div>
          <div style={{ flex: 1 }}>
            <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'cardioActivity')}</label>
            <select value={activity} onChange={e => setActivity(e.target.value)} style={{ ...inputStyle, marginTop: 4 }}>
              {CARDIO_ACTIVITIES.map(a => (
                <option key={a.key} value={a.key}>{t(langApp, a.labelKey)}</option>
              ))}
            </select>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <div style={{ flex: 1 }}>
            <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'cardioDuration')}</label>
            <div style={{ display: 'flex', gap: 4, marginTop: 4 }}>
              <input type="number" min="0" placeholder="min" value={minutes} onChange={e => setMinutes(e.target.value)} style={inputStyle} />
              <input type="number" min="0" max="59" placeholder="sec" value={seconds} onChange={e => setSeconds(e.target.value)} style={inputStyle} />
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'cardioDistance')} ({distUnit})</label>
            <input type="number" min="0" step="0.01" value={distance} onChange={e => setDistance(e.target.value)} style={{ ...inputStyle, marginTop: 4 }} />
          </div>
        </div>
        <div>
          <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'cardioNotes')}</label>
          <input type="text" maxLength={300} value={notes} onChange={e => setNotes(e.target.value)} style={{ ...inputStyle, marginTop: 4 }} />
        </div>
        {saveMsg && (
          <div style={{ fontSize: 11.5, color: saveMsg.ok ? '#8fc98f' : '#e08a8a' }}>{saveMsg.text}</div>
        )}
        <button type="submit" disabled={saving} style={{
          padding: '9px 14px', borderRadius: 10, border: 'none',
          background: '#5ADECD', color: '#1B1930', fontWeight: 600, fontSize: 12.5,
          cursor: saving ? 'default' : 'pointer', opacity: saving ? 0.6 : 1, fontFamily: '"Inter", sans-serif',
          transition: 'opacity 0.15s ease',
        }}>
          {saving ? <InlineWait langApp={langApp} /> : t(langApp, 'cardioSave')}
        </button>
      </form>

      {loading && <div style={{ fontSize: 12, color: '#9694B0', marginBottom: 10 }}><InlineWait langApp={langApp} /></div>}
      {loadError && <div style={{ fontSize: 12, color: '#e08a8a', marginBottom: 10 }}>{loadError}</div>}

      {!loading && !loadError && chartData.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>
            {mostlyHaveDistance ? t(langApp, 'cardioPaceChart') : t(langApp, 'cardioDurationChart')}
          </div>
          <SimpleTrendChart
            data={chartData}
            dataKey={mostlyHaveDistance ? 'pace' : 'durationMin'}
            color="#5ADECD"
            valueFormatter={(v) => mostlyHaveDistance ? `${fmtKg(v)} min/${distUnit}` : `${fmtKg(v)} min`}
            langApp={langApp}
          />
        </div>
      )}

      <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>
        {t(langApp, 'cardioList')}
      </div>
      {!loading && !loadError && sessions.length === 0 && (
        <div style={{ fontSize: 12, color: '#6E6C8E' }}>{t(langApp, 'cardioNoSessions')}</div>
      )}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxHeight: 260, overflowY: 'auto', scrollBehavior: 'smooth' }}>
        {sessions.map(s => {
          const hasDistance = s.distance_meters != null && s.distance_meters > 0;
          const distDisplay = hasDistance ? convertDistanceKm(s.distance_meters / 1000, weightUnit) : null;
          const durMin = Math.floor(s.duration_seconds / 60);
          const durSec = s.duration_seconds % 60;
          return (
            <div key={s.id} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '8px 10px', borderRadius: 8, background: '#1B1930', border: '1px solid #3A3856',
            }}>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 12.5, fontWeight: 600, color: '#EDEBFF' }}>
                  {t(langApp, CARDIO_ACTIVITIES.find(a => a.key === s.activity)?.labelKey || 'cardioActivityOther') || s.activity} &middot; {fmtDate(s.date)}
                </div>
                <div style={{ fontSize: 11, color: '#9694B0' }}>
                  {durMin}:{String(durSec).padStart(2, '0')} {hasDistance ? `· ${fmtKg(distDisplay)} ${distUnit}` : ''}
                  {s.notes ? ` · ${s.notes}` : ''}
                </div>
              </div>
              <button onClick={() => handleDelete(s.id)} disabled={deletingId === s.id} style={{
                background: 'none', border: 'none', color: '#e08a8a', fontSize: 11,
                cursor: deletingId === s.id ? 'default' : 'pointer', opacity: deletingId === s.id ? 0.6 : 1,
                fontFamily: '"Inter", sans-serif', flexShrink: 0, padding: '4px 6px',
                transition: 'opacity 0.15s ease',
              }}>
                {deletingId === s.id ? <InlineWait langApp={langApp} /> : t(langApp, 'cardioDelete')}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// Pannello "Metriche corporee": peso, altezza+BMI, circonferenze.
// Usa esclusivamente supabase-js su body_weight_logs / body_height / body_measurements (RLS auth.uid()=user_id).
function BodyMetricsPanel({ langApp, userId, weightUnit }) {
  // --- Peso corporeo ---
  const [weightLogs, setWeightLogs] = useState([]);
  const [loadingWeight, setLoadingWeight] = useState(true);
  const [weightLoadError, setWeightLoadError] = useState(null);
  const [weightDate, setWeightDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [weightInput, setWeightInput] = useState('');
  const [savingWeight, setSavingWeight] = useState(false);
  const [weightSaveMsg, setWeightSaveMsg] = useState(null);

  // --- Altezza ---
  const [height, setHeight] = useState(null); // riga corrente da body_height, null finché non caricata
  const [loadingHeight, setLoadingHeight] = useState(true);
  const [heightLoadError, setHeightLoadError] = useState(null);
  const [heightInput, setHeightInput] = useState('');
  const [savingHeight, setSavingHeight] = useState(false);
  const [heightSaveMsg, setHeightSaveMsg] = useState(null);

  // --- Circonferenze ---
  const [selectedZone, setSelectedZone] = useState(MEASUREMENT_ZONES[0].key);
  const [measurements, setMeasurements] = useState([]);
  const [loadingMeasurements, setLoadingMeasurements] = useState(true);
  const [measurementsLoadError, setMeasurementsLoadError] = useState(null);
  const [measurementDate, setMeasurementDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [measurementInput, setMeasurementInput] = useState('');
  const [savingMeasurement, setSavingMeasurement] = useState(false);
  const [measurementSaveMsg, setMeasurementSaveMsg] = useState(null);

  async function loadWeight() {
    setLoadingWeight(true);
    setWeightLoadError(null);
    const { data, error } = await supabase
      .from('body_weight_logs')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: true });
    if (error) setWeightLoadError(error.message || t(langApp, 'bodyWeightLoadError'));
    else setWeightLogs(data || []);
    setLoadingWeight(false);
  }

  async function loadHeight() {
    setLoadingHeight(true);
    setHeightLoadError(null);
    const { data, error } = await supabase
      .from('body_height')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    if (error) setHeightLoadError(error.message || t(langApp, 'bodyHeightLoadError'));
    else {
      setHeight(data || null);
      if (data) setHeightInput(String(data.height_cm));
    }
    setLoadingHeight(false);
  }

  async function loadMeasurements() {
    setLoadingMeasurements(true);
    setMeasurementsLoadError(null);
    const { data, error } = await supabase
      .from('body_measurements')
      .select('*')
      .eq('user_id', userId)
      .order('date', { ascending: true });
    if (error) setMeasurementsLoadError(error.message || t(langApp, 'measurementLoadError'));
    else setMeasurements(data || []);
    setLoadingMeasurements(false);
  }

  useEffect(() => {
    if (!userId) return;
    loadWeight();
    loadHeight();
    loadMeasurements();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  async function handleSaveWeight(e) {
    e.preventDefault();
    setWeightSaveMsg(null);
    const val = parseFloat(weightInput);
    if (isNaN(val) || val <= 0) {
      setWeightSaveMsg({ ok: false, text: t(langApp, 'bodyWeightInvalid') });
      return;
    }
    // l'input è nell'unità corrente (kg o lb): il DB vuole sempre kg
    const weightKg = weightUnit === 'lb' ? val / KG_TO_LB : val;
    setSavingWeight(true);
    try {
      // upsert su (user_id, date): se l'utente registra due volte lo stesso giorno, aggiorna invece di duplicare
      const { error } = await supabase.from('body_weight_logs')
        .upsert({ user_id: userId, date: weightDate, weight_kg: Math.round(weightKg * 10) / 10 }, { onConflict: 'user_id,date' });
      if (error) throw error;
      setWeightSaveMsg({ ok: true, text: t(langApp, 'bodyWeightSave') });
      setWeightInput('');
      await loadWeight();
    } catch (err) {
      setWeightSaveMsg({ ok: false, text: err.message || t(langApp, 'bodyWeightSaveError') });
    } finally {
      setSavingWeight(false);
    }
  }

  async function handleSaveHeight(e) {
    e.preventDefault();
    setHeightSaveMsg(null);
    const val = parseFloat(heightInput);
    if (isNaN(val) || val <= 0) {
      setHeightSaveMsg({ ok: false, text: t(langApp, 'bodyHeightInvalid') });
      return;
    }
    setSavingHeight(true);
    try {
      // body_height ha user_id come PRIMARY KEY: una sola riga per utente, upsert su quel vincolo
      const { error } = await supabase.from('body_height')
        .upsert({ user_id: userId, height_cm: val, updated_at: new Date().toISOString() }, { onConflict: 'user_id' });
      if (error) throw error;
      setHeightSaveMsg({ ok: true, text: t(langApp, 'bodyHeightSave') });
      await loadHeight();
    } catch (err) {
      setHeightSaveMsg({ ok: false, text: err.message || t(langApp, 'bodyHeightSaveError') });
    } finally {
      setSavingHeight(false);
    }
  }

  async function handleSaveMeasurement(e) {
    e.preventDefault();
    setMeasurementSaveMsg(null);
    const val = parseFloat(measurementInput);
    if (isNaN(val) || val <= 0) {
      setMeasurementSaveMsg({ ok: false, text: t(langApp, 'measurementInvalid') });
      return;
    }
    setSavingMeasurement(true);
    try {
      // upsert su (user_id, date, measurement_type): stessa zona+data aggiorna invece di duplicare
      const { error } = await supabase.from('body_measurements')
        .upsert({
          user_id: userId, date: measurementDate, measurement_type: selectedZone, value_cm: val,
        }, { onConflict: 'user_id,date,measurement_type' });
      if (error) throw error;
      setMeasurementSaveMsg({ ok: true, text: t(langApp, 'measurementSave') });
      setMeasurementInput('');
      await loadMeasurements();
    } catch (err) {
      setMeasurementSaveMsg({ ok: false, text: err.message || t(langApp, 'measurementSaveError') });
    } finally {
      setSavingMeasurement(false);
    }
  }

  const weightChartData = useMemo(() => weightLogs.map(w => ({ ts: toTs(w.date), weight: convertWeight(w.weight_kg, weightUnit) })), [weightLogs, weightUnit]);

  const latestWeightKg = weightLogs.length > 0 ? weightLogs[weightLogs.length - 1].weight_kg : null;
  const bmi = (latestWeightKg != null && height && height.height_cm)
    ? latestWeightKg / Math.pow(height.height_cm / 100, 2)
    : null;

  const zoneData = useMemo(() => {
    return measurements
      .filter(m => m.measurement_type === selectedZone)
      .sort((a, b) => a.date.localeCompare(b.date))
      .map(m => ({ ts: toTs(m.date), value: m.value_cm }));
  }, [measurements, selectedZone]);

  const inputStyle = {
    width: '100%', padding: '9px 12px', borderRadius: 8,
    background: '#1B1930', border: '1px solid #4A4870', color: '#EDEBFF',
    fontSize: 12.5, fontFamily: '"Inter", sans-serif',
  };
  const zoneLabel = (key) => t(langApp, MEASUREMENT_ZONES.find(z => z.key === key)?.labelKey || key);

  return (
    <div style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: 14, marginBottom: 16 }}>
      <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 12 }}>
        {t(langApp, 'bodyMetrics')}
      </div>

      {/* --- Peso corporeo --- */}
      <div style={{ fontSize: 12.5, fontWeight: 600, color: '#EDEBFF', marginBottom: 8 }}>{t(langApp, 'bodyWeightTitle')}</div>
      <form onSubmit={handleSaveWeight} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'flex-end' }}>
        <div style={{ flex: 1 }}>
          <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'bodyWeightDate')}</label>
          <input type="date" value={weightDate} onChange={e => setWeightDate(e.target.value)} style={{ ...inputStyle, marginTop: 4 }} />
        </div>
        <div style={{ flex: 1 }}>
          <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'bodyWeightValue')} ({weightUnitLabel(weightUnit)})</label>
          <input type="number" min="0" step="0.1" value={weightInput} onChange={e => setWeightInput(e.target.value)} style={{ ...inputStyle, marginTop: 4 }} />
        </div>
        <button type="submit" disabled={savingWeight} style={{
          padding: '9px 14px', borderRadius: 8, border: 'none', background: '#5ADECD', color: '#1B1930',
          fontWeight: 600, fontSize: 12, cursor: savingWeight ? 'default' : 'pointer', opacity: savingWeight ? 0.6 : 1,
          fontFamily: '"Inter", sans-serif', flexShrink: 0, transition: 'opacity 0.15s ease',
        }}>
          {savingWeight ? <InlineWait langApp={langApp} /> : t(langApp, 'save')}
        </button>
      </form>
      {weightSaveMsg && <div style={{ fontSize: 11.5, marginBottom: 8, color: weightSaveMsg.ok ? '#8fc98f' : '#e08a8a' }}>{weightSaveMsg.text}</div>}
      {loadingWeight && <div style={{ fontSize: 12, color: '#9694B0', marginBottom: 10 }}><InlineWait langApp={langApp} /></div>}
      {weightLoadError && <div style={{ fontSize: 12, color: '#e08a8a', marginBottom: 10 }}>{weightLoadError}</div>}
      {!loadingWeight && !weightLoadError && weightChartData.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 10.5, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>{t(langApp, 'bodyWeightChart')}</div>
          <SimpleTrendChart data={weightChartData} dataKey="weight" color="#5ADECD"
            valueFormatter={(v) => `${fmtKg(v)} ${weightUnitLabel(weightUnit)}`} langApp={langApp} />
        </div>
      )}

      {/* --- Altezza + BMI --- */}
      <div style={{ paddingTop: 14, marginTop: 4, borderTop: '1px solid #3A3856' }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: '#EDEBFF', marginBottom: 8 }}>{t(langApp, 'bodyHeightTitle')}</div>
        <form onSubmit={handleSaveHeight} style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'flex-end' }}>
          <div style={{ flex: 1 }}>
            <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'bodyHeightValue')}</label>
            <input type="number" min="0" step="0.1" value={heightInput} onChange={e => setHeightInput(e.target.value)} style={{ ...inputStyle, marginTop: 4 }} />
          </div>
          <button type="submit" disabled={savingHeight} style={{
            padding: '9px 14px', borderRadius: 8, border: 'none', background: '#5ADECD', color: '#1B1930',
            fontWeight: 600, fontSize: 12, cursor: savingHeight ? 'default' : 'pointer', opacity: savingHeight ? 0.6 : 1,
            fontFamily: '"Inter", sans-serif', flexShrink: 0, transition: 'opacity 0.15s ease',
          }}>
            {savingHeight ? <InlineWait langApp={langApp} /> : t(langApp, 'save')}
          </button>
        </form>
        {heightSaveMsg && <div style={{ fontSize: 11.5, marginBottom: 8, color: heightSaveMsg.ok ? '#8fc98f' : '#e08a8a' }}>{heightSaveMsg.text}</div>}
        {loadingHeight && <div style={{ fontSize: 12, color: '#9694B0', marginBottom: 8 }}><InlineWait langApp={langApp} /></div>}
        {heightLoadError && <div style={{ fontSize: 12, color: '#e08a8a', marginBottom: 8 }}>{heightLoadError}</div>}
        {bmi != null && (
          <div style={{ background: '#1B1930', border: '1px solid #3A3856', borderRadius: 10, padding: '10px 12px', marginBottom: 8 }}>
            <div style={{ fontSize: 12, color: '#D4D2E8' }}>{t(langApp, 'bmiLabel')}: <strong style={{ color: '#5ADECD' }}>{fmtKg(bmi)}</strong></div>
            <div style={{ fontSize: 10.5, color: '#6E6C8E', marginTop: 4, lineHeight: 1.4 }}>{t(langApp, 'bmiNote')}</div>
          </div>
        )}
      </div>

      {/* --- Circonferenze --- */}
      <div style={{ paddingTop: 14, marginTop: 14, borderTop: '1px solid #3A3856' }}>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: '#EDEBFF', marginBottom: 8 }}>{t(langApp, 'measurementsTitle')}</div>
        <form onSubmit={handleSaveMeasurement} style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 10 }}>
          <div>
            <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'measurementZone')}</label>
            <select value={selectedZone} onChange={e => setSelectedZone(e.target.value)} style={{ ...inputStyle, marginTop: 4 }}>
              {MEASUREMENT_ZONES.map(z => (
                <option key={z.key} value={z.key}>{t(langApp, z.labelKey)}</option>
              ))}
            </select>
          </div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
            <div style={{ flex: 1 }}>
              <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'measurementDate')}</label>
              <input type="date" value={measurementDate} onChange={e => setMeasurementDate(e.target.value)} style={{ ...inputStyle, marginTop: 4 }} />
            </div>
            <div style={{ flex: 1 }}>
              <label style={{ fontSize: 10.5, color: '#9694B0' }}>{t(langApp, 'measurementValue')}</label>
              <input type="number" min="0" step="0.1" value={measurementInput} onChange={e => setMeasurementInput(e.target.value)} style={{ ...inputStyle, marginTop: 4 }} />
            </div>
            <button type="submit" disabled={savingMeasurement} style={{
              padding: '9px 14px', borderRadius: 8, border: 'none', background: '#5ADECD', color: '#1B1930',
              fontWeight: 600, fontSize: 12, cursor: savingMeasurement ? 'default' : 'pointer', opacity: savingMeasurement ? 0.6 : 1,
              fontFamily: '"Inter", sans-serif', flexShrink: 0, transition: 'opacity 0.15s ease',
            }}>
              {savingMeasurement ? <InlineWait langApp={langApp} /> : t(langApp, 'save')}
            </button>
          </div>
        </form>
        {measurementSaveMsg && <div style={{ fontSize: 11.5, marginBottom: 8, color: measurementSaveMsg.ok ? '#8fc98f' : '#e08a8a' }}>{measurementSaveMsg.text}</div>}
        {loadingMeasurements && <div style={{ fontSize: 12, color: '#9694B0', marginBottom: 8 }}><InlineWait langApp={langApp} /></div>}
        {measurementsLoadError && <div style={{ fontSize: 12, color: '#e08a8a', marginBottom: 8 }}>{measurementsLoadError}</div>}
        {!loadingMeasurements && !measurementsLoadError && (
          zoneData.length > 0 ? (
            <div>
              <div style={{ fontSize: 10.5, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>
                {t(langApp, 'measurementChart')} &mdash; {zoneLabel(selectedZone)}
              </div>
              <SimpleTrendChart data={zoneData} dataKey="value" color="#8B7FE8"
                valueFormatter={(v) => `${fmtKg(v)} cm`} langApp={langApp} />
            </div>
          ) : (
            <div style={{ fontSize: 12, color: '#6E6C8E' }}>{t(langApp, 'measurementNoData')}</div>
          )
        )}
      </div>
    </div>
  );
}

function WorkoutBodyExplorer({ initialRaw, userId, onDataChange, onLogout, onDeleteAccount, langApp, langExercise, weightUnit, onChangeLangApp, onChangeLangExercise, onChangeWeightUnit, profile, onProfileUpdated }) {
  const [raw, setRawState] = useState(initialRaw);

  // ogni volta che i dati grezzi cambiano (nuovo export caricato), sincronizza col backend e col parent
  function setRaw(updater) {
    setRawState(prev => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      onDataChange(next);
      return next;
    });
  }

  const [hiddenExercises, setHiddenExercises] = useState(new Set());
  // soglia minima esecuzioni per mostrare un esercizio: di default 1 (mostra tutto) al primissimo accesso,
  // ma se l'utente la modifica resta salvata per sempre (per-account, persistita in localStorage) finché non la ritocca
  const [minCount, setMinCountState] = useState(() => {
    const saved = localStorage_get(MIN_COUNT_KEY_PREFIX + userId);
    const parsed = saved !== null ? parseInt(saved, 10) : NaN;
    return Number.isFinite(parsed) ? parsed : DEFAULT_MIN_COUNT;
  });
  function setMinCount(value) {
    setMinCountState(value);
    localStorage_set(MIN_COUNT_KEY_PREFIX + userId, String(value));
  }
  // vista del grafico: null = tutto lo storico (auto-fit); altrimenti [startTs, endTs] in millisecondi.
  // Sostituisce il vecchio Brush a indici discreti con un pan/zoom continuo in stile trading.
  const [viewDomain, setViewDomain] = useState(null);
  const [selected, setSelected] = useState('Petto');
  const [view, setView] = useState('front');
  const [compareExercises, setCompareExercises] = useState([]); // array di nomi esercizio in confronto
  const [showManage, setShowManage] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showFriends, setShowFriends] = useState(false);
  const [showCompareAdd, setShowCompareAdd] = useState(false);
  const [uploadMsg, setUploadMsg] = useState(null);
  // "Altre sezioni" raggruppa Cardio e Metriche corporee in un menu a comparsa: evita di affollare
  // la barra azioni principale con troppi bottoni (già upload/gestisci/amici/impostazioni), restando
  // comunque usabile su schermo di telefono.
  const [showOtherSectionsMenu, setShowOtherSectionsMenu] = useState(false);
  const [showCardio, setShowCardio] = useState(false);
  const [showBodyMetrics, setShowBodyMetrics] = useState(false);
  // app di provenienza scelta per l'aggiornamento export (selezione manuale, non auto-detect)
  const [updateImportApp, setUpdateImportApp] = useState('liftoff');
  const [updateMappingState, setUpdateMappingState] = useState(null); // { headers, rows } quando serve mappatura manuale

  function closeAllPanels() {
    setShowManage(false); setShowSettings(false); setShowFriends(false);
    setShowCardio(false); setShowBodyMetrics(false); setShowOtherSectionsMenu(false);
  }

  // stato per il form "modifica profilo" nelle impostazioni: username (case sensitive, modificabile)
  // e foto profilo (URL). Niente più nome visualizzato/bio, tolti perché ridondanti con lo username.
  const [editUsername, setEditUsername] = useState(profile?.username || '');
  const [editAvatarUrl, setEditAvatarUrl] = useState(profile?.avatar_url || '');
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileSaveMsg, setProfileSaveMsg] = useState(null);

  async function handleSaveProfile() {
    setProfileSaveMsg(null);
    const uname = editUsername.trim();
    if (!USERNAME_REGEX.test(uname)) {
      setProfileSaveMsg({ ok: false, text: t(langApp, 'usernameInvalid') });
      return;
    }
    setSavingProfile(true);
    try {
      const { error } = await supabase.from('profiles').update({
        username: uname,
        avatar_url: editAvatarUrl.trim() || null,
        updated_at: new Date().toISOString(),
      }).eq('id', userId);
      if (error) {
        // violazione univocità username: codice standard Postgres per unique_violation
        if (error.code === '23505') {
          setProfileSaveMsg({ ok: false, text: t(langApp, 'usernameTaken') });
        } else {
          throw error;
        }
        return;
      }
      setProfileSaveMsg({ ok: true, text: t(langApp, 'profileSaved') });
      if (onProfileUpdated) onProfileUpdated({ ...profile, username: uname, avatar_url: editAvatarUrl.trim() || null });
    } catch (err) {
      setProfileSaveMsg({ ok: false, text: err.message || t(langApp, 'authGenericError') });
    } finally {
      setSavingProfile(false);
    }
  }

  // conteggio occorrenze per esercizio sul dataset grezzo corrente
  const exerciseCounts = useMemo(() => {
    const c = {};
    raw.forEach(r => { c[r[1]] = (c[r[1]]||0) + 1; });
    return c;
  }, [raw]);

  const maxExerciseCount = useMemo(() => {
    const counts = Object.values(exerciseCounts);
    return counts.length ? Math.max(...counts) : 1;
  }, [exerciseCounts]);

  // dataset dopo applicazione soglia minima e nascondimenti manuali
  const filteredRaw = useMemo(() => {
    return raw.filter(r => {
      const ex = r[1];
      if (hiddenExercises.has(ex)) return false;
      if ((exerciseCounts[ex]||0) < minCount) return false;
      return true;
    });
  }, [raw, hiddenExercises, minCount, exerciseCounts]);

  const availableGroups = useMemo(() => new Set(filteredRaw.map(r => r[2])), [filteredRaw]);
  const GROUPS = useMemo(() => GROUP_ORDER.filter(g => availableGroups.has(g)), [availableGroups]);

  useEffect(() => {
    if (GROUPS.length && !GROUPS.includes(selected)) setSelected(GROUPS[0]);
  }, [GROUPS]);

  const ALL_DATES = useMemo(() => raw.map(r => r[0]), [raw]);
  const FIRST_TS = useMemo(() => {
    if (!ALL_DATES.length) return Date.now();
    return new Date(ALL_DATES.reduce((a,b) => a < b ? a : b)).getTime();
  }, [ALL_DATES]);
  const TODAY_TS = useMemo(() => new Date(new Date().toISOString().slice(0,10)).getTime(), []);

  // ogni 1 gennaio compreso tra il primo workout e oggi, per le linee verticali di riferimento
  const newYearTicks = useMemo(() => {
    const startYear = new Date(FIRST_TS).getFullYear();
    const endYear = new Date(TODAY_TS).getFullYear();
    const ticks = [];
    for (let y = startYear + 1; y <= endYear; y++) {
      const ts = new Date(`${y}-01-01`).getTime();
      if (ts > FIRST_TS && ts < TODAY_TS) ticks.push(ts);
    }
    return ticks;
  }, [FIRST_TS, TODAY_TS]);

  const groupData = useMemo(() => filteredRaw.filter(r => r[2] === selected), [filteredRaw, selected]);

  const exercisesInGroup = useMemo(() => {
    const counts = {};
    groupData.forEach(r => { counts[r[1]] = (counts[r[1]]||0) + 1; });
    return Object.keys(counts).sort((a,b) => counts[b] - counts[a]);
  }, [groupData]);

  // lista completa esercizi disponibili (tutti i gruppi), per il pannello di confronto cross-gruppo
  const allAvailableExercises = useMemo(() => {
    const map = {};
    const counts = {};
    filteredRaw.forEach(r => {
      map[r[1]] = r[2];
      counts[r[1]] = (counts[r[1]]||0) + 1;
    });
    return Object.entries(map)
      .map(([name, group]) => ({ name, group, count: counts[name] }))
      .sort((a,b) => a.group.localeCompare(b.group) || counts[b.name] - counts[a.name]);
  }, [filteredRaw]);

  function toggleCompareExercise(name) {
    setCompareExercises(prev => {
      if (prev.includes(name)) return prev.filter(e => e !== name);
      return [...prev, name];
    });
  }

  const COMPARE_COLORS = ['#5ADECD', '#4FA8D8', '#8B7FE8', '#5AC9DE', '#C77FE0', '#7F8FE8', '#5AE0A8', '#5AB8E0'];
  const colorForExercise = (name) => {
    const idx = compareExercises.indexOf(name);
    return COMPARE_COLORS[idx % COMPARE_COLORS.length] || '#9694B0';
  };

  // per ogni esercizio in confronto: righe grezze + serie per sessione.
  // Un esercizio è "a corpo libero" se la maggior parte delle serie storiche ha peso 0 — serve solo per scegliere
  // come ETICHETTARE il grafico (rip. vs kg). La metrica per singola sessione invece guarda quella sessione:
  // se quel giorno c'è stata zavorra (peso > 0), la forza è il peso aggiunto stimato a 1 rep (Epley);
  // se quel giorno il peso è 0 (corpo libero puro), la forza sono le reps massime.
  // Così un Dips zavorrato un giorno e libero un altro giorno viene rappresentato correttamente in entrambi i casi,
  // invece di essere bloccato su una sola convenzione per tutto lo storico.
  const perExerciseSeries = useMemo(() => {
    return compareExercises.map(name => {
      const rows = filteredRaw.filter(r => r[1] === name);
      const isBodyweight = rows.length > 0 && rows.filter(r => r[3] === 0).length / rows.length > 0.8;
      const bySession = {};
      rows.forEach(([date, ex, grp, weight, reps]) => {
        const hasLoad = weight > 0;
        const est1RM = reps <= 1 ? weight : weight * (1 + reps / 30);
        // metrica comparabile all'interno della stessa sessione: se c'è carico usiamo il peso stimato (kg),
        // altrimenti le reps pure. Le due scale non sono equivalenti tra loro, ma per scegliere la "serie top"
        // del giorno confrontiamo solo cose omogenee: diamo priorità a una sessione con carico su una senza.
        const metric = hasLoad ? est1RM : reps;
        const key = date;
        if (!bySession[key]) bySession[key] = { date, ts: toTs(date), strength: 0, topWeight: 0, topReps: 0, hasLoad: false };
        const better = hasLoad && !bySession[key].hasLoad
          ? true // una serie con carico batte sempre una senza, quel giorno
          : (hasLoad === bySession[key].hasLoad && metric > bySession[key].strength);
        if (better) {
          bySession[key].strength = metric;
          bySession[key].topWeight = weight;
          bySession[key].topReps = reps;
          bySession[key].hasLoad = hasLoad;
        }
      });
      const points = Object.values(bySession).sort((a,b) => a.ts - b.ts);
      return { name, rows, points, color: colorForExercise(name), isBodyweight };
    });
  }, [compareExercises, filteredRaw]);

  // merge di tutte le serie su un unico asse temporale per il grafico multi-linea
  const mergedChartData = useMemo(() => {
    const byTs = {};
    perExerciseSeries.forEach(series => {
      series.points.forEach(p => {
        if (!byTs[p.ts]) byTs[p.ts] = { ts: p.ts, date: p.date };
        byTs[p.ts][series.name] = p.strength;
        byTs[p.ts][series.name + '__detail'] = p.hasLoad
          ? `${fmtWeight(p.topWeight, weightUnit)}${weightUnitLabel(weightUnit)} × ${p.topReps}`
          : `${p.topReps} rip. a corpo libero`;
        byTs[p.ts][series.name + '__hasLoad'] = p.hasLoad;
      });
    });
    return Object.values(byTs).sort((a,b) => a.ts - b.ts);
  }, [perExerciseSeries, weightUnit]);

  const statsByExercise = useMemo(() => {
    const out = {};
    perExerciseSeries.forEach(series => {
      if (series.points.length === 0) { out[series.name] = null; return; }
      const loadedPoints = series.points.filter(p => p.hasLoad);
      const bodyweightPoints = series.points.filter(p => !p.hasLoad);
      const hasMixed = loadedPoints.length > 0 && bodyweightPoints.length > 0;
      // se esistono sessioni con carico, le statistiche "di forza" si basano su quelle (più informative);
      // altrimenti si basano sulle reps a corpo libero.
      const relevantPoints = loadedPoints.length > 0 ? loadedPoints : bodyweightPoints;
      const maxStrength = Math.max(...relevantPoints.map(p => p.strength));
      const first = series.points[0].strength;
      const last = series.points[series.points.length-1].strength;
      const lastHasLoad = series.points[series.points.length-1].hasLoad;
      out[series.name] = {
        maxStrength, first, last, lastHasLoad,
        sessions: series.points.length, totalSets: series.rows.length,
        isBodyweight: series.isBodyweight,
        statsAreLoaded: loadedPoints.length > 0,
        hasMixed,
      };
    });
    return out;
  }, [perExerciseSeries]);

  const groupStats = useMemo(() => {
    const totalSets = groupData.length;
    const sessions = new Set(groupData.map(r => r[0])).size;
    const totalVolume = Math.round(groupData.reduce((s,r) => s + r[3]*r[4], 0));
    return { totalSets, sessions, totalVolume };
  }, [groupData]);

  // tutti gli esercizi mai visti nel dataset grezzo, con conteggio e stato visibilita
  const allExercisesList = useMemo(() => {
    const list = Object.keys(exerciseCounts).map(ex => ({
      name: ex,
      count: exerciseCounts[ex],
      group: guessGroup(ex),
      hidden: hiddenExercises.has(ex) || exerciseCounts[ex] < minCount,
      manuallyHidden: hiddenExercises.has(ex),
      belowThreshold: exerciseCounts[ex] < minCount,
    }));
    return list.sort((a,b) => b.count - a.count);
  }, [exerciseCounts, hiddenExercises, minCount]);

  function toggleExercise(name) {
    setHiddenExercises(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name); else next.add(name);
      return next;
    });
  }

  // unisce le nuove righe convertite nel dataset esistente, deduplicando su data+esercizio+peso+reps
  function mergeNewRows(newRows) {
    if (newRows.length === 0) {
      setUploadMsg({ ok: false, text: t(langApp, 'importNoValidRows') });
      return;
    }
    setRaw(prev => {
      const seen = new Set(prev.map(r => r.join('|')));
      const merged = [...prev];
      let added = 0;
      for (const row of newRows) {
        const key = row.join('|');
        if (!seen.has(key)) { merged.push(row); seen.add(key); added++; }
      }
      setUploadMsg({ ok: true, text: langApp === 'en'
        ? `Updated: ${added} new sets imported (out of ${newRows.length} read from the file).`
        : `Aggiornato: ${added} nuove serie importate (su ${newRows.length} lette dal file).` });
      return merged;
    });
  }

  function handleFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    setUploadMsg(null);
    // "Altro formato CSV": prima leggiamo solo l'header (preview:1) per popolare il selettore di mappatura,
    // poi applichiamo la mappatura scelta dall'utente a tutto il file in un secondo passaggio.
    if (updateImportApp === 'other') {
      Papa.parse(file, {
        header: true, skipEmptyLines: true, preview: 1,
        complete: (previewResult) => {
          const headers = previewResult.meta && previewResult.meta.fields ? previewResult.meta.fields : [];
          if (!headers.length) {
            setUploadMsg({ ok: false, text: t(langApp, 'importParseError') });
            return;
          }
          setUpdateMappingState({ headers, file });
        },
        error: (err) => {
          setUploadMsg({ ok: false, text: `${t(langApp, 'importParseError')}: ${err.message}` });
        }
      });
      e.target.value = '';
      return;
    }
    Papa.parse(file, {
      ...papaOptionsForImportApp(updateImportApp),
      complete: (results) => {
        try {
          const { rows: newRows } = rowsForImportApp(updateImportApp, results.data);
          mergeNewRows(newRows);
        } catch (err) {
          setUploadMsg({ ok: false, text: err.message || t(langApp, 'importParseError') });
        }
      },
      error: (err) => {
        setUploadMsg({ ok: false, text: `${t(langApp, 'importParseError')}: ${err.message}` });
      }
    });
    e.target.value = '';
  }

  // applica la mappatura manuale scelta dall'utente ("Altro formato CSV") a tutto il file
  function handleConfirmMapping(mapping, defaultWeightUnit) {
    const file = updateMappingState.file;
    setUpdateMappingState(null);
    Papa.parse(file, {
      header: true, skipEmptyLines: true,
      complete: (results) => {
        try {
          const newRows = mappedRowsToRaw(results.data, mapping, defaultWeightUnit);
          mergeNewRows(newRows);
        } catch (err) {
          setUploadMsg({ ok: false, text: err.message || t(langApp, 'importParseError') });
        }
      },
      error: (err) => {
        setUploadMsg({ ok: false, text: `${t(langApp, 'importParseError')}: ${err.message}` });
      }
    });
  }

  return (
    <div className="wbe-root" style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #1B1930 0%, #211F38 100%)',
      color: '#EDEBFF',
      fontFamily: '"Inter", system-ui, sans-serif',
      paddingTop: 'max(16px, env(safe-area-inset-top))',
      paddingBottom: 'max(16px, env(safe-area-inset-bottom))',
      paddingLeft: 'max(12px, env(safe-area-inset-left))',
      paddingRight: 'max(12px, env(safe-area-inset-right))',
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;700&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-thumb { background: #4A4870; border-radius: 3px; }
        .group-scroll { scroll-snap-type: x proximity; }
        input[type="file"] { display: none; }
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(-6px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .panel-anim { animation: fadeSlideIn 0.2s ease; }
        html { scroll-behavior: smooth; }

        /* Schermi molto piccoli (iPhone SE e simili, 320-360px): il padding laterale di 12px del
           contenitore esterno lascia poco margine, riduciamo leggermente font/spaziature dei blocchi
           più affollati (barra azioni, titoli) senza toccare i valori px usati altrove per il resto. */
        @media (max-width: 360px) {
          .wbe-container { padding-left: 2px; padding-right: 2px; }
          .wbe-actionbar button, .wbe-actionbar label { font-size: 11px !important; }
        }

        /* Tablet/desktop: il layout resta mobile-first ma può respirare un po' di più invece di
           restare bloccato a 480px con largo spazio vuoto scuro ai lati. */
        @media (min-width: 768px) {
          .wbe-container { max-width: 600px !important; }
        }

        /* Landscape su telefono (schermo molto corto in altezza): il grafico e la BodyMap sono gli
           elementi verticalmente più ingombranti, li comprimiamo per lasciare spazio al resto senza
           forzare uno scroll eccessivo per raggiungere tabelle/legenda sottostanti. */
        @media (orientation: landscape) and (max-height: 500px) {
          .trading-chart-container { height: clamp(160px, 40vh, 240px) !important; }
          .bodymap-svg { width: 130px !important; height: 208px !important; }
        }
      `}</style>

      <div className="wbe-container" style={{ width: '100%', maxWidth: 480, margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
          <div>
            <h1 style={{ fontFamily:'"Oswald", sans-serif', fontSize: 20, fontWeight: 500, margin: 0, letterSpacing: 0.3, color: '#9694B0' }}>
              {t(langApp, 'subtitle')}
            </h1>
          </div>
        </div>

        {/* barra azioni: aggiorna dati + gestisci esercizi + amici + impostazioni + altre sezioni.
            L'app di provenienza va scelta PRIMA del file, quindi il selettore sta sopra il bottone upload
            invece che dentro una label unica: eviterebbe di poter cambiare app dopo aver già aperto il picker. */}
        <div style={{ marginBottom: 8 }}>
          <ImportAppSelector value={updateImportApp} onChange={setUpdateImportApp} langApp={langApp} />
        </div>
        <div className="wbe-actionbar" style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
          <label style={{
            flex: 1, minWidth: 120, textAlign: 'center', padding: '9px 10px', borderRadius: 10,
            background: '#252341', border: '1px solid #4A4870', color: '#D4D2E8',
            fontSize: 12, fontFamily: '"Inter", sans-serif', cursor: 'pointer', fontWeight: 500,
            transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
          }}>
            &#8593; {t(langApp, 'updateExport')}
            <input type="file" accept=".csv" onChange={handleFileUpload} />
          </label>
          <button onClick={() => { const v = !showManage; closeAllPanels(); setShowManage(v); }} style={{
            padding: '9px 14px', borderRadius: 10,
            background: showManage ? '#5ADECD' : '#252341',
            border: '1px solid #4A4870', color: showManage ? '#1B1930' : '#D4D2E8',
            fontSize: 12, fontFamily: '"Inter", sans-serif', cursor: 'pointer', fontWeight: 500,
            transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
          }}>
            {t(langApp, 'manage')}
          </button>
          <button onClick={() => { const v = !showFriends; closeAllPanels(); setShowFriends(v); }} aria-label={t(langApp, 'friends')} style={{
            width: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 10,
            background: showFriends ? '#5ADECD' : '#252341',
            border: '1px solid #4A4870', color: showFriends ? '#1B1930' : '#D4D2E8',
            fontSize: 16, cursor: 'pointer', flexShrink: 0,
            transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
          }}>
            &#128101;
          </button>
          <button onClick={() => { const v = !showOtherSectionsMenu; closeAllPanels(); setShowOtherSectionsMenu(v); }} aria-label={t(langApp, 'otherSections')} style={{
            width: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 10,
            background: showOtherSectionsMenu ? '#5ADECD' : '#252341',
            border: '1px solid #4A4870', color: showOtherSectionsMenu ? '#1B1930' : '#D4D2E8',
            fontSize: 16, cursor: 'pointer', flexShrink: 0,
            transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
          }}>
            &#8942;
          </button>
          <button onClick={() => { const v = !showSettings; closeAllPanels(); setShowSettings(v); }} aria-label={t(langApp, 'settings')} style={{
            width: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 10,
            background: showSettings ? '#5ADECD' : '#252341',
            border: '1px solid #4A4870', color: showSettings ? '#1B1930' : '#D4D2E8',
            fontSize: 16, cursor: 'pointer', flexShrink: 0,
            transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
          }}>
            &#9881;
          </button>
        </div>

        {updateMappingState && (
          <ImportMappingModal
            headers={updateMappingState.headers}
            langApp={langApp}
            defaultWeightUnit={weightUnit}
            onCancel={() => setUpdateMappingState(null)}
            onConfirm={handleConfirmMapping}
          />
        )}

        {showFriends && (
          profile
            ? <div key="friends-panel" className="panel-anim"><FriendsPanel langApp={langApp} myUserId={userId} /></div>
            : (
              // account "legacy" a codice personale, non ancora migrato a email/password:
              // niente profilo pubblico => niente ricerca/amicizie finché non fa la migrazione
              // (evita di mostrare un pannello che sembra funzionare ma non troverebbe/salverebbe nulla).
              <div key="friends-need-migration" className="panel-anim" style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: 14, marginBottom: 16, fontSize: 12.5, color: '#D4D2E8', lineHeight: 1.5 }}>
                {t(langApp, 'friendsNeedMigration')}
              </div>
            )
        )}

        {/* menu "Altre sezioni": Cardio e Metriche corporee, raggruppati per non affollare la barra principale */}
        {showOtherSectionsMenu && (
          <div key="other-sections-menu" className="panel-anim" style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: 10, marginBottom: 16, display: 'flex', gap: 8 }}>
            <button onClick={() => { setShowCardio(v => !v); setShowBodyMetrics(false); }} style={{
              flex: 1, padding: '9px 10px', borderRadius: 10,
              background: showCardio ? '#5ADECD' : '#1B1930',
              border: '1px solid #4A4870', color: showCardio ? '#1B1930' : '#D4D2E8',
              fontSize: 12, fontFamily: '"Inter", sans-serif', cursor: 'pointer', fontWeight: 500,
              transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
            }}>
              &#127939; {t(langApp, 'cardio')}
            </button>
            <button onClick={() => { setShowBodyMetrics(v => !v); setShowCardio(false); }} style={{
              flex: 1, padding: '9px 10px', borderRadius: 10,
              background: showBodyMetrics ? '#5ADECD' : '#1B1930',
              border: '1px solid #4A4870', color: showBodyMetrics ? '#1B1930' : '#D4D2E8',
              fontSize: 12, fontFamily: '"Inter", sans-serif', cursor: 'pointer', fontWeight: 500,
              transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
            }}>
              &#128207; {t(langApp, 'bodyMetrics')}
            </button>
          </div>
        )}

        {showCardio && (
          profile
            ? <div key="cardio-panel" className="panel-anim"><CardioPanel langApp={langApp} userId={userId} weightUnit={weightUnit} /></div>
            : (
              <div key="cardio-need-migration" className="panel-anim" style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: 14, marginBottom: 16, fontSize: 12.5, color: '#D4D2E8', lineHeight: 1.5 }}>
                {t(langApp, 'cardioNeedMigration')}
              </div>
            )
        )}

        {showBodyMetrics && (
          profile
            ? <div key="bodymetrics-panel" className="panel-anim"><BodyMetricsPanel langApp={langApp} userId={userId} weightUnit={weightUnit} /></div>
            : (
              <div key="bodymetrics-need-migration" className="panel-anim" style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: 14, marginBottom: 16, fontSize: 12.5, color: '#D4D2E8', lineHeight: 1.5 }}>
                {t(langApp, 'bodyMetricsNeedMigration')}
              </div>
            )
        )}

        {uploadMsg && (
          <div className="panel-anim" style={{
            padding: '8px 12px', borderRadius: 8, marginBottom: 14, fontSize: 12,
            background: uploadMsg.ok ? '#1e2a1e' : '#2a1e1e',
            color: uploadMsg.ok ? '#8fc98f' : '#e08a8a',
            border: `1px solid ${uploadMsg.ok ? '#3a4a3a' : '#4a3a3a'}`,
          }}>
            {uploadMsg.text}
          </div>
        )}

        {showSettings && (
          <div key="settings-panel" className="panel-anim" style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: 14, marginBottom: 16 }}>
            <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>
              {t(langApp, 'settings')}
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <span style={{ fontSize: 12, color: '#D4D2E8' }}>{t(langApp, 'appLanguage')}</span>
              <div style={{ display: 'flex', gap: 4, background: '#1B1930', padding: 3, borderRadius: 8 }}>
                {['it', 'en'].map(l => (
                  <button key={l} onClick={() => onChangeLangApp(l)} style={{
                    padding: '4px 10px', borderRadius: 6, border: 'none', cursor: 'pointer',
                    background: langApp === l ? '#5ADECD' : 'transparent',
                    color: langApp === l ? '#1B1930' : '#9694B0',
                    fontSize: 11, fontWeight: 600, fontFamily: '"Inter", sans-serif',
                    transition: 'background 0.15s ease, color 0.15s ease',
                  }}>{l.toUpperCase()}</button>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <span style={{ fontSize: 12, color: '#D4D2E8' }}>{t(langApp, 'exerciseLanguage')}</span>
              <div style={{ display: 'flex', gap: 4, background: '#1B1930', padding: 3, borderRadius: 8 }}>
                {['it', 'en'].map(l => (
                  <button key={l} onClick={() => onChangeLangExercise(l)} style={{
                    padding: '4px 10px', borderRadius: 6, border: 'none', cursor: 'pointer',
                    background: langExercise === l ? '#5ADECD' : 'transparent',
                    color: langExercise === l ? '#1B1930' : '#9694B0',
                    fontSize: 11, fontWeight: 600, fontFamily: '"Inter", sans-serif',
                    transition: 'background 0.15s ease, color 0.15s ease',
                  }}>{l.toUpperCase()}</button>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <span style={{ fontSize: 12, color: '#D4D2E8' }}>{t(langApp, 'weightUnit')}</span>
              <div style={{ display: 'flex', gap: 4, background: '#1B1930', padding: 3, borderRadius: 8 }}>
                {['kg', 'lb'].map(u => (
                  <button key={u} onClick={() => onChangeWeightUnit(u)} style={{
                    padding: '4px 10px', borderRadius: 6, border: 'none', cursor: 'pointer',
                    background: weightUnit === u ? '#5ADECD' : 'transparent',
                    color: weightUnit === u ? '#1B1930' : '#9694B0',
                    fontSize: 11, fontWeight: 600, fontFamily: '"Inter", sans-serif',
                    transition: 'background 0.15s ease, color 0.15s ease',
                  }}>{u.toUpperCase()}</button>
                ))}
              </div>
            </div>

            {/* modifica profilo: username (modificabile, case sensitive) e foto profilo.
                Solo per account email/password con un profilo reale — un account legacy a codice
                personale non ha una riga in profiles finché non fa la migrazione. */}
            {profile && (
            <div style={{ paddingTop: 14, marginTop: 4, borderTop: '1px solid #3A3856' }}>
              <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>
                {t(langApp, 'editProfile')}
              </div>
              <input type="text" value={editUsername} onChange={e => setEditUsername(e.target.value)}
                placeholder={t(langApp, 'usernamePlaceholder')} autoCapitalize="none" autoCorrect="off" style={{
                  width: '100%', padding: '9px 12px', borderRadius: 8, marginBottom: 6,
                  background: '#1B1930', border: '1px solid #4A4870', color: '#EDEBFF', fontSize: 12.5, fontFamily: '"Inter", sans-serif',
                }} />
              <div style={{ fontSize: 10, color: '#6E6C8E', marginBottom: 10 }}>{t(langApp, 'usernameHint')}</div>
              <div style={{ fontSize: 11, color: '#9694B0', marginBottom: 8 }}>{t(langApp, 'avatarUrl')}</div>
              <AvatarUploader userId={userId} avatarUrl={editAvatarUrl} onUploaded={setEditAvatarUrl} langApp={langApp} />
              {profileSaveMsg && (
                <div style={{ fontSize: 11, marginBottom: 8, color: profileSaveMsg.ok ? '#8fc98f' : '#e08a8a' }}>{profileSaveMsg.text}</div>
              )}
              <button onClick={handleSaveProfile} disabled={savingProfile} style={{
                width: '100%', padding: '9px 14px', borderRadius: 10, border: 'none',
                background: '#5ADECD', color: '#1B1930', fontWeight: 600, fontSize: 12,
                cursor: savingProfile ? 'default' : 'pointer', opacity: savingProfile ? 0.6 : 1,
                fontFamily: '"Inter", sans-serif', transition: 'opacity 0.15s ease',
              }}>
                {savingProfile ? <InlineWait langApp={langApp} /> : t(langApp, 'saveProfile')}
              </button>
            </div>
            )}

            {/* per un account legacy (senza profilo) offriamo qui il modo per avviare la migrazione:
                serve fare logout e poi scegliere "Ho già un account con codice personale" nella
                schermata di accesso, dato che quel flusso richiede un login/registrazione email pulito. */}
            {!profile && (
              <div style={{ paddingTop: 14, marginTop: 4, borderTop: '1px solid #3A3856', fontSize: 12, color: '#9694B0', lineHeight: 1.5 }}>
                {t(langApp, 'legacyAccountSettingsHint')}
              </div>
            )}

            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 14, marginTop: 14, borderTop: '1px solid #3A3856' }}>
              <button onClick={() => {
                if (window.confirm(t(langApp, 'logoutConfirm'))) {
                  onLogout();
                }
              }} style={{
                padding: '9px 14px', borderRadius: 10, textAlign: 'center',
                background: '#1B1930', border: '1px solid #4A4870', color: '#D4D2E8',
                fontSize: 12, fontFamily: '"Inter", sans-serif', cursor: 'pointer', fontWeight: 500,
              }}>
                {t(langApp, 'logout')}
              </button>
              <button onClick={() => {
                if (window.confirm(t(langApp, 'deleteAccountConfirm')) && window.confirm(t(langApp, 'deleteAccountConfirmFinal'))) {
                  onDeleteAccount();
                }
              }} style={{
                padding: '9px 14px', borderRadius: 10, textAlign: 'center',
                background: '#2a1e1e', border: '1px solid #4a3a3a', color: '#e08a8a',
                fontSize: 12, fontFamily: '"Inter", sans-serif', cursor: 'pointer', fontWeight: 500,
              }}>
                {t(langApp, 'deleteAccount')}
              </button>
            </div>
          </div>
        )}

        {showManage && (
          <div key="manage-panel" className="panel-anim" style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: 14, marginBottom: 16 }}>
            <div style={{ fontSize: 12, color: '#D4D2E8', marginBottom: 10 }}>
              {t(langApp, 'minSetsCount')}: <strong style={{color:'#5ADECD'}}>{minCount}</strong>
            </div>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 6 }}>
              <input type="range" min="1" max={maxExerciseCount} value={minCount}
                onChange={e => setMinCount(parseInt(e.target.value))}
                style={{ flex: 1 }} />
              <input type="number" min="1" max={maxExerciseCount} value={minCount}
                onChange={e => {
                  const v = parseInt(e.target.value);
                  if (!isNaN(v)) setMinCount(Math.max(1, Math.min(maxExerciseCount, v)));
                }}
                style={{
                  width: 56, padding: '5px 6px', borderRadius: 6, textAlign: 'center',
                  background: '#1B1930', border: '1px solid #4A4870', color: '#EDEBFF', fontSize: 12,
                }} />
            </div>
            <div style={{ fontSize: 10, color: '#6E6C8E', marginBottom: 14 }}>
              {t(langApp, 'hiddenAuto')}
            </div>
            <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>
              {t(langApp, 'allExercises')} ({allExercisesList.length}) &mdash; {t(langApp, 'tapToToggle')}
            </div>
            <div style={{ maxHeight: 280, overflowY: 'auto', scrollBehavior: 'smooth', display: 'flex', flexDirection: 'column', gap: 4 }}>
              {allExercisesList.map(ex => (
                <button key={ex.name} onClick={() => toggleExercise(ex.name)}
                  disabled={ex.belowThreshold && !ex.manuallyHidden}
                  style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '7px 10px', borderRadius: 8, border: 'none', textAlign: 'left',
                    background: ex.hidden ? '#1B1930' : '#2E2C4A',
                    color: ex.hidden ? '#6E6C8E' : '#EDEBFF',
                    fontSize: 12, fontFamily: '"Inter", sans-serif',
                    cursor: (ex.belowThreshold && !ex.manuallyHidden) ? 'default' : 'pointer',
                    opacity: (ex.belowThreshold && !ex.manuallyHidden) ? 0.6 : 1,
                    textDecoration: ex.hidden ? 'line-through' : 'none',
                    transition: 'background 0.15s ease, color 0.15s ease, opacity 0.15s ease',
                  }}>
                  <span>{translateExercise(ex.name, langExercise)} <span style={{color:'#6E6C8E', fontSize:10}}>&middot; {ex.group}</span></span>
                  <span style={{ color: '#9694B0', fontSize: 11 }}>{ex.count}&times;</span>
                </button>
              ))}
            </div>
          </div>
        )}

        <div style={{ color: '#9694B0', fontSize: 12, marginBottom: 14 }}>
          {t(langApp, 'tapMuscleGroup')}
        </div>

        {/* corpo + gruppi */}
        <div style={{ background: '#252341', borderRadius: 14, padding: '16px 12px', border: '1px solid #3A3856', marginBottom: 14 }}>
          <BodyMap selected={selected} onSelect={setSelected} view={view} setView={setView} availableGroups={availableGroups} />
        </div>

        <div className="group-scroll" style={{ display: 'flex', gap: 6, overflowX: 'auto', paddingBottom: 4, marginBottom: 18, WebkitOverflowScrolling: 'touch', scrollBehavior: 'smooth' }}>
          {GROUPS.map(g => (
            <button key={g} onClick={() => setSelected(g)}
              style={{
                display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0,
                padding: '7px 12px', borderRadius: 20, border: `1px solid ${selected===g ? GROUP_COLOR[g] : '#4A4870'}`,
                background: selected === g ? '#2E2C4A' : 'transparent',
                fontFamily: '"Inter", sans-serif', fontSize: 12.5,
                color: selected === g ? '#EDEBFF' : '#9694B0',
                fontWeight: selected === g ? 600 : 400,
                whiteSpace: 'nowrap', cursor: 'pointer',
                transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
              }}>
              <span style={{ width: 8, height: 8, borderRadius: 2, background: GROUP_COLOR[g], flexShrink: 0 }} />
              {translateGroup(g, langApp)}
            </button>
          ))}
        </div>

        <div>
          <div style={{ marginBottom: 4 }}>
            <h2 style={{ fontFamily:'"Oswald", sans-serif', fontSize: 20, fontWeight: 600, margin: 0, color: GROUP_COLOR[selected] }}>
              {translateGroup(selected, langApp)}
            </h2>
            <span style={{ color: '#9694B0', fontSize: 12 }}>
              {groupStats.sessions} {t(langApp, 'sessions')} &middot; {groupStats.totalSets} {t(langApp, 'sets')} &middot; {fmtWeight(groupStats.totalVolume, weightUnit)} {t(langApp, 'totalVolume').replace('kg ', '')}
            </span>
          </div>

          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', margin: '14px 0' }}>
            {exercisesInGroup.map(ex => (
              <button key={ex} onClick={() => toggleCompareExercise(ex)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '6px 11px', borderRadius: 20,
                  border: `1px solid ${compareExercises.includes(ex) ? colorForExercise(ex) : '#4A4870'}`,
                  background: compareExercises.includes(ex) ? '#2E2C4A' : 'transparent',
                  color: compareExercises.includes(ex) ? '#EDEBFF' : '#D4D2E8',
                  fontSize: 11.5, fontWeight: 500, cursor: 'pointer', fontFamily: '"Inter", sans-serif',
                  transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
                }}>
                {compareExercises.includes(ex) && <span style={{ width: 8, height: 8, borderRadius: 4, background: colorForExercise(ex), flexShrink: 0 }} />}
                {translateExercise(ex, langExercise)}
              </button>
            ))}
          </div>

          {/* aggiungi esercizi da confrontare da qualsiasi gruppo */}
          <button onClick={() => setShowCompareAdd(v => !v)} style={{
            width: '100%', textAlign: 'left', padding: '8px 12px', borderRadius: 10, marginBottom: 12,
            background: showCompareAdd ? '#2E2C4A' : '#252341', border: '1px solid #3A3856',
            color: '#D4D2E8', fontSize: 12, fontFamily: '"Inter", sans-serif', cursor: 'pointer',
            transition: 'background 0.15s ease',
          }}>
            + {t(langApp, 'compareOtherGroup')}
          </button>

          {showCompareAdd && (
            <div key="compare-add-panel" className="panel-anim" style={{ background: '#252341', border: '1px solid #3A3856', borderRadius: 10, padding: 10, marginBottom: 16, maxHeight: 220, overflowY: 'auto', scrollBehavior: 'smooth' }}>
              {GROUPS.map(g => (
                <div key={g} style={{ marginBottom: 8 }}>
                  <div style={{ fontSize: 10, color: GROUP_COLOR[g], textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 }}>{translateGroup(g, langApp)}</div>
                  <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                    {allAvailableExercises.filter(e => e.group === g).map(e => (
                      <button key={e.name} onClick={() => toggleCompareExercise(e.name)}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 5,
                          padding: '5px 9px', borderRadius: 16,
                          border: `1px solid ${compareExercises.includes(e.name) ? colorForExercise(e.name) : '#4A4870'}`,
                          background: compareExercises.includes(e.name) ? '#2E2C4A' : 'transparent',
                          color: compareExercises.includes(e.name) ? '#EDEBFF' : '#9694B0',
                          fontSize: 10.5, cursor: 'pointer', fontFamily: '"Inter", sans-serif',
                          transition: 'background 0.15s ease, color 0.15s ease, border-color 0.15s ease',
                        }}>
                        {compareExercises.includes(e.name) && <span style={{ width: 6, height: 6, borderRadius: 3, background: colorForExercise(e.name), flexShrink: 0 }} />}
                        {translateExercise(e.name, langExercise)}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {compareExercises.length > 0 && (
            <>
              {/* statistiche per ogni esercizio in confronto */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
                {compareExercises.map(ex => {
                  const s = statsByExercise[ex];
                  if (!s) return null;
                  return (
                    <div key={ex} style={{ background: '#252341', border: `1px solid #3A3856`, borderLeft: `3px solid ${colorForExercise(ex)}`, borderRadius: 10, padding: '10px 12px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                        <span style={{ fontSize: 12.5, fontWeight: 600, color: '#EDEBFF' }}>{translateExercise(ex, langExercise)}</span>
                        <button onClick={() => toggleCompareExercise(ex)} style={{
                          background: 'none', border: 'none', color: '#9694B0', fontSize: 14, cursor: 'pointer', padding: '6px 6px',
                        }}>&times;</button>
                      </div>
                      <div style={{ display: 'flex', gap: 14, fontSize: 11, color: '#9694B0' }}>
                        <span>{t(langApp,'max')}: <strong style={{color:'#EDEBFF'}}>{s.statsAreLoaded ? fmtWeight(s.maxStrength, weightUnit) + weightUnitLabel(weightUnit) : Math.round(s.maxStrength) + ' rip.'}</strong></span>
                        <span>{t(langApp,'last')}: <strong style={{color:'#EDEBFF'}}>{s.lastHasLoad ? fmtWeight(s.last, weightUnit) + weightUnitLabel(weightUnit) : Math.round(s.last) + ' rip.'}</strong></span>
                        <span>{t(langApp,'sessions')}: <strong style={{color:'#EDEBFF'}}>{s.sessions}</strong></span>
                      </div>
                      {s.hasMixed && (
                        <div style={{ fontSize: 10, color: '#6E6C8E', marginTop: 6 }}>
                          {t(langApp, 'mixedNote')}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div style={{ fontSize: 11, color: '#9694B0', marginBottom: 10, lineHeight: 1.5 }}>
                {t(langApp, 'strengthChartNote')}
              </div>

              <TradingStyleChart
                mergedChartData={mergedChartData}
                compareExercises={compareExercises}
                colorForExercise={colorForExercise}
                firstTs={FIRST_TS}
                todayTs={TODAY_TS}
                newYearTicks={newYearTicks}
                viewDomain={viewDomain}
                setViewDomain={setViewDomain}
                weightUnit={weightUnit}
                langExercise={langExercise}
                langApp={langApp}
              />

              {/* legenda colori */}
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', margin: '10px 0 18px' }}>
                {compareExercises.map(ex => (
                  <div key={ex} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 10.5, color: '#9694B0' }}>
                    <span style={{ width: 8, height: 8, borderRadius: 4, background: colorForExercise(ex) }} />
                    {translateExercise(ex, langExercise)}
                  </div>
                ))}
              </div>

              {/* tabelle dettaglio per ciascun esercizio in confronto */}
              {perExerciseSeries.map(series => (
                <div key={series.name} style={{ marginBottom: 18 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10.5, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>
                    <span style={{ width: 8, height: 8, borderRadius: 4, background: series.color }} />
                    {t(langApp, 'latestSessions')} &mdash; {translateExercise(series.name, langExercise)}
                  </div>
                  <div style={{ maxHeight: 180, overflowY: 'auto', overflowX: 'auto', WebkitOverflowScrolling: 'touch', scrollBehavior: 'smooth', border: '1px solid #3A3856', borderRadius: 10 }}>
                    <table style={{ width: '100%', minWidth: 280, borderCollapse: 'collapse', fontSize: 11.5 }}>
                      <thead>
                        <tr style={{ background: '#2E2C4A', position: 'sticky', top: 0 }}>
                          <th style={{ textAlign: 'left', padding: '7px 10px', color: '#9694B0', fontWeight: 500 }}>{t(langApp, 'date')}</th>
                          <th style={{ textAlign: 'right', padding: '7px 10px', color: '#9694B0', fontWeight: 500 }}>{t(langApp, 'topSet')}</th>
                          <th style={{ textAlign: 'right', padding: '7px 10px', color: '#9694B0', fontWeight: 500 }}>{t(langApp, 'value')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[...series.points].reverse().map((d,i) => (
                          <tr key={i} style={{ borderTop: '1px solid #3A3856' }}>
                            <td style={{ padding: '6px 10px', color: '#D4D2E8' }}>{fmtDate(d.date)}</td>
                            <td style={{ padding: '6px 10px', textAlign: 'right', color: '#EDEBFF', fontWeight: 600 }}>
                              {d.hasLoad ? `${fmtWeight(d.topWeight, weightUnit)}${weightUnitLabel(weightUnit)}×${d.topReps}` : `${d.topReps} rip. (${langApp === 'en' ? 'bodyweight' : 'corpo libero'})`}
                            </td>
                            <td style={{ padding: '6px 10px', textAlign: 'right', color: '#9694B0' }}>
                              {d.hasLoad ? `${fmtWeight(d.strength, weightUnit)}${weightUnitLabel(weightUnit)}` : Math.round(d.strength)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// Piccolo spinner testuale riusato ovunque per stati di caricamento, come da pattern già esistente in app
function InlineWait({ langApp }) {
  return <span>{t(langApp, 'pleaseWait')}</span>;
}

// Nuova schermata di ingresso principale: tab Accedi/Registrati con email+password (Supabase Auth).
// Sostituisce l'ex-default a "codice personale", che ora resta raggiungibile solo dal link di migrazione.
function EmailAuthScreen({ onAuthSession, langApp, onStartLegacyMigration }) {
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [info, setInfo] = useState(null);

  function validate() {
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
    if (!emailOk) { setError(t(langApp, 'invalidEmail')); return false; }
    if (password.length < 6) { setError(t(langApp, 'passwordTooShort')); return false; }
    return true;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    if (!validate()) return;
    setLoading(true);
    try {
      if (mode === 'register') {
        const { data, error: signUpError } = await supabase.auth.signUp({ email: email.trim(), password });
        if (signUpError) throw signUpError;
        // se la conferma email è richiesta lato progetto, la sessione potrebbe non essere immediata:
        // in quel caso avvisiamo l'utente invece di restare bloccati in silenzio.
        if (data.session) {
          onAuthSession(data.session, true); // true = account appena creato ora (per il cleanup se abbandona il primo upload)
        } else {
          setInfo(langApp === 'en'
            ? 'Check your inbox to confirm your email, then log in.'
            : 'Controlla la tua email per confermare la registrazione, poi accedi.');
        }
      } else {
        const { data, error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (signInError) throw signInError;
        onAuthSession(data.session, false);
      }
    } catch (err) {
      setError(err.message || t(langApp, 'authGenericError'));
    } finally {
      setLoading(false);
    }
  }

  async function handleGoogle() {
    if (!GOOGLE_OAUTH_ENABLED) return; // bottone disabilitato finché il provider non è configurato lato Supabase
    try {
      await supabase.auth.signInWithOAuth({ provider: 'google' });
    } catch (err) {
      setError(err.message || t(langApp, 'authGenericError'));
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #1B1930 0%, #211F38 100%)',
      color: '#EDEBFF',
      fontFamily: '"Inter", system-ui, sans-serif',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      paddingTop: 'max(20px, env(safe-area-inset-top))',
      paddingBottom: 'max(20px, env(safe-area-inset-bottom))',
      paddingLeft: 'max(20px, env(safe-area-inset-left))',
      paddingRight: 'max(20px, env(safe-area-inset-right))',
    }}>
      <style dangerouslySetInnerHTML={{__html: `* { box-sizing: border-box; }`}} />
      <div style={{ width: '100%', maxWidth: 360 }}>
        <h1 style={{ fontFamily:'"Oswald", sans-serif', fontSize: 22, fontWeight: 500, marginBottom: 4, textAlign: 'center', color: '#EDEBFF' }}>
          {t(langApp, 'subtitle')}
        </h1>

        <div style={{ display: 'flex', gap: 8, margin: '20px 0', background: '#1a1a1a', padding: 4, borderRadius: 8 }}>
          <button onClick={() => { setMode('login'); setError(null); setInfo(null); }} style={{
            flex: 1, padding: '8px 12px', borderRadius: 6, border: 'none', cursor: 'pointer',
            fontFamily: '"Oswald", sans-serif', fontSize: 12, letterSpacing: 0.5, textTransform: 'uppercase',
            background: mode === 'login' ? '#5ADECD' : 'transparent',
            color: mode === 'login' ? '#1B1930' : '#9694B0',
            transition: 'background 0.15s ease, color 0.15s ease',
          }}>{t(langApp, 'login')}</button>
          <button onClick={() => { setMode('register'); setError(null); setInfo(null); }} style={{
            flex: 1, padding: '8px 12px', borderRadius: 6, border: 'none', cursor: 'pointer',
            fontFamily: '"Oswald", sans-serif', fontSize: 12, letterSpacing: 0.5, textTransform: 'uppercase',
            background: mode === 'register' ? '#5ADECD' : 'transparent',
            color: mode === 'register' ? '#1B1930' : '#9694B0',
            transition: 'background 0.15s ease, color 0.15s ease',
          }}>{t(langApp, 'register')}</button>
        </div>

        <form onSubmit={handleSubmit}>
          <input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder={t(langApp, 'email')}
            autoCapitalize="none"
            autoCorrect="off"
            style={{
              width: '100%', padding: '12px 14px', borderRadius: 10,
              background: '#252341', border: '1px solid #4A4870', color: '#EDEBFF',
              fontSize: 15, fontFamily: '"Inter", sans-serif', marginBottom: 10,
            }}
          />
          <input
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder={t(langApp, 'password')}
            style={{
              width: '100%', padding: '12px 14px', borderRadius: 10,
              background: '#252341', border: '1px solid #4A4870', color: '#EDEBFF',
              fontSize: 15, fontFamily: '"Inter", sans-serif', marginBottom: 12,
            }}
          />
          {error && <div style={{ color: '#e08a8a', fontSize: 12, marginBottom: 12 }}>{error}</div>}
          {info && <div style={{ color: '#8fc98f', fontSize: 12, marginBottom: 12 }}>{info}</div>}
          <button type="submit" disabled={loading} style={{
            width: '100%', padding: '12px 14px', borderRadius: 10, border: 'none',
            background: '#5ADECD', color: '#1B1930', fontWeight: 600, fontSize: 14,
            cursor: loading ? 'default' : 'pointer', opacity: loading ? 0.6 : 1,
            fontFamily: '"Oswald", sans-serif', letterSpacing: 0.5, textTransform: 'uppercase',
            transition: 'opacity 0.15s ease',
          }}>
            {loading ? <InlineWait langApp={langApp} /> : (mode === 'register' ? t(langApp, 'createAccount') : t(langApp, 'login'))}
          </button>
        </form>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '18px 0', color: '#6E6C8E', fontSize: 11 }}>
          <div style={{ flex: 1, height: 1, background: '#3A3856' }} />
          {t(langApp, 'orDivider')}
          <div style={{ flex: 1, height: 1, background: '#3A3856' }} />
        </div>

        {/* Google OAuth predisposto lato Supabase ma non ancora configurato: bottone visibile
            ma disattivato, con badge "presto disponibile", finché GOOGLE_OAUTH_ENABLED non passa a true. */}
        <button onClick={handleGoogle} disabled={!GOOGLE_OAUTH_ENABLED} title={!GOOGLE_OAUTH_ENABLED ? t(langApp, 'googleNotConfiguredNote') : undefined} style={{
          width: '100%', padding: '11px 14px', borderRadius: 10,
          background: '#252341', border: '1px solid #4A4870',
          color: GOOGLE_OAUTH_ENABLED ? '#D4D2E8' : '#6E6C8E',
          fontSize: 13, fontFamily: '"Inter", sans-serif', fontWeight: 500,
          cursor: GOOGLE_OAUTH_ENABLED ? 'pointer' : 'not-allowed',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          marginBottom: 18, transition: 'color 0.15s ease',
        }}>
          {t(langApp, 'loginWithGoogle')}
          {!GOOGLE_OAUTH_ENABLED && (
            <span style={{
              fontSize: 9.5, padding: '2px 6px', borderRadius: 10, background: '#3A3856', color: '#9694B0',
              textTransform: 'uppercase', letterSpacing: 0.5,
            }}>{t(langApp, 'comingSoon')}</span>
          )}
        </button>

        <button onClick={onStartLegacyMigration} style={{
          width: '100%', textAlign: 'center', background: 'none', border: 'none',
          color: '#9694B0', fontSize: 12, textDecoration: 'underline', cursor: 'pointer', padding: 6,
        }}>
          {t(langApp, 'haveLegacyCode')}
        </button>
      </div>
    </div>
  );
}

// Flusso di migrazione da vecchio account "a codice personale": chiede il codice, poi guida
// l'utente a loggarsi/registrarsi con email+password (riusando AuthScreen legacy per il codice
// e un mini form email/password), infine chiama la RPC migrate_legacy_account per spostare i dati.
function LegacyMigrationFlow({ langApp, onBack, onMigrated }) {
  const [step, setStep] = useState('code'); // 'code' | 'auth' | 'migrating'
  const [code, setCode] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authMode, setAuthMode] = useState('login'); // 'login' | 'register', per il nuovo account email
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  function handleCodeSubmit(e) {
    e.preventDefault();
    setError(null);
    if (code.trim().length < 4) {
      setError(langApp === 'en' ? 'The code must be at least 4 characters.' : 'Il codice deve avere almeno 4 caratteri.');
      return;
    }
    setStep('auth');
  }

  async function runMigration() {
    setStep('migrating');
    setError(null);
    try {
      const { error: rpcError } = await supabase.rpc('migrate_legacy_account', { p_code: code.trim() });
      if (rpcError) throw rpcError;
      onMigrated();
    } catch (err) {
      // messaggio chiaro per il caso più comune: codice non trovato/già usato
      const msg = (err.message || '').toLowerCase().includes('not found') || (err.message || '').toLowerCase().includes('non trovat')
        ? t(langApp, 'legacyCodeNotFound')
        : (err.message || t(langApp, 'authGenericError'));
      setError(msg);
      setStep('auth');
    }
  }

  async function handleAuthSubmit(e) {
    e.preventDefault();
    setError(null);
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
    if (!emailOk) { setError(t(langApp, 'invalidEmail')); return; }
    if (password.length < 6) { setError(t(langApp, 'passwordTooShort')); return; }
    setLoading(true);
    try {
      if (authMode === 'register') {
        const { data, error: signUpError } = await supabase.auth.signUp({ email: email.trim(), password });
        if (signUpError) throw signUpError;
        if (!data.session) {
          setLoading(false);
          setError(langApp === 'en'
            ? 'Check your inbox to confirm your email, then come back and log in to finish the migration.'
            : 'Controlla la tua email per confermare la registrazione, poi torna qui e accedi per completare il recupero.');
          return;
        }
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (signInError) throw signInError;
      }
      setLoading(false);
      await runMigration();
    } catch (err) {
      setLoading(false);
      setError(err.message || t(langApp, 'authGenericError'));
    }
  }

  const inputStyle = {
    width: '100%', padding: '12px 14px', borderRadius: 10,
    background: '#252341', border: '1px solid #4A4870', color: '#EDEBFF',
    fontSize: 15, fontFamily: '"Inter", sans-serif', marginBottom: 10,
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #1B1930 0%, #211F38 100%)',
      color: '#EDEBFF',
      fontFamily: '"Inter", system-ui, sans-serif',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      paddingTop: 'max(20px, env(safe-area-inset-top))',
      paddingBottom: 'max(20px, env(safe-area-inset-bottom))',
      paddingLeft: 'max(20px, env(safe-area-inset-left))',
      paddingRight: 'max(20px, env(safe-area-inset-right))',
      position: 'relative',
    }}>
      <button onClick={onBack} style={{
        position: 'absolute', top: 'max(20px, env(safe-area-inset-top))', left: 'max(20px, env(safe-area-inset-left))',
        background: 'none', border: 'none', color: '#9694B0', fontSize: 20,
        cursor: 'pointer', padding: 8, lineHeight: 1,
      }} aria-label={t(langApp, 'back')}>&#8592;</button>

      <div style={{ width: '100%', maxWidth: 360 }}>
        <h1 style={{ fontFamily:'"Oswald", sans-serif', fontSize: 20, fontWeight: 600, marginBottom: 8, textAlign: 'center' }}>
          {t(langApp, 'legacyMigrationTitle')}
        </h1>
        <p style={{ color: '#9694B0', fontSize: 13, marginBottom: 20, lineHeight: 1.5, textAlign: 'center' }}>
          {t(langApp, 'legacyMigrationIntro')}
        </p>

        {step === 'code' && (
          <form onSubmit={handleCodeSubmit}>
            <input type="text" value={code} onChange={e => setCode(e.target.value)}
              placeholder={t(langApp, 'codePlaceholder')} autoCapitalize="none" autoCorrect="off" style={inputStyle} />
            {error && <div style={{ color: '#e08a8a', fontSize: 12, marginBottom: 12 }}>{error}</div>}
            <button type="submit" style={{
              width: '100%', padding: '12px 14px', borderRadius: 10, border: 'none',
              background: '#5ADECD', color: '#1B1930', fontWeight: 600, fontSize: 14, cursor: 'pointer',
              fontFamily: '"Oswald", sans-serif', letterSpacing: 0.5, textTransform: 'uppercase',
            }}>{t(langApp, 'continueWithEmail')}</button>
          </form>
        )}

        {(step === 'auth' || step === 'migrating') && (
          <form onSubmit={handleAuthSubmit}>
            <div style={{ display: 'flex', gap: 8, marginBottom: 14, background: '#1a1a1a', padding: 4, borderRadius: 8 }}>
              <button type="button" onClick={() => setAuthMode('login')} style={{
                flex: 1, padding: '7px 12px', borderRadius: 6, border: 'none', cursor: 'pointer',
                fontFamily: '"Oswald", sans-serif', fontSize: 11.5, letterSpacing: 0.5, textTransform: 'uppercase',
                background: authMode === 'login' ? '#5ADECD' : 'transparent',
                color: authMode === 'login' ? '#1B1930' : '#9694B0',
                transition: 'background 0.15s ease, color 0.15s ease',
              }}>{t(langApp, 'login')}</button>
              <button type="button" onClick={() => setAuthMode('register')} style={{
                flex: 1, padding: '7px 12px', borderRadius: 6, border: 'none', cursor: 'pointer',
                fontFamily: '"Oswald", sans-serif', fontSize: 11.5, letterSpacing: 0.5, textTransform: 'uppercase',
                background: authMode === 'register' ? '#5ADECD' : 'transparent',
                color: authMode === 'register' ? '#1B1930' : '#9694B0',
                transition: 'background 0.15s ease, color 0.15s ease',
              }}>{t(langApp, 'register')}</button>
            </div>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder={t(langApp, 'email')} autoCapitalize="none" autoCorrect="off" style={inputStyle} />
            <input type="password" value={password} onChange={e => setPassword(e.target.value)}
              placeholder={t(langApp, 'password')} style={inputStyle} />
            {error && <div style={{ color: '#e08a8a', fontSize: 12, marginBottom: 12 }}>{error}</div>}
            <button type="submit" disabled={loading || step === 'migrating'} style={{
              width: '100%', padding: '12px 14px', borderRadius: 10, border: 'none',
              background: '#5ADECD', color: '#1B1930', fontWeight: 600, fontSize: 14,
              cursor: (loading || step === 'migrating') ? 'default' : 'pointer',
              opacity: (loading || step === 'migrating') ? 0.6 : 1,
              fontFamily: '"Oswald", sans-serif', letterSpacing: 0.5, textTransform: 'uppercase',
              transition: 'opacity 0.15s ease',
            }}>
              {(loading || step === 'migrating') ? <InlineWait langApp={langApp} /> : (authMode === 'register' ? t(langApp, 'createAccount') : t(langApp, 'login'))}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

// Ridimensiona/comprime un'immagine lato client prima dell'upload: la riporta a un quadrato di
// max 512x512 (crop centrale) e la ricodifica in JPEG a qualità 0.85, così anche una foto da 10MB
// diretta dalla fotocamera diventa un file da poche decine di KB prima di salire su Storage.
function resizeImageToJpeg(file, maxSize = 512, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const reader = new FileReader();
    reader.onload = () => { img.src = reader.result; };
    reader.onerror = () => reject(new Error('read-failed'));
    img.onload = () => {
      const side = Math.min(img.width, img.height);
      const sx = (img.width - side) / 2;
      const sy = (img.height - side) / 2;
      const outSize = Math.min(maxSize, side);
      const canvas = document.createElement('canvas');
      canvas.width = outSize;
      canvas.height = outSize;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, sx, sy, side, side, 0, 0, outSize, outSize);
      canvas.toBlob(blob => {
        if (!blob) { reject(new Error('encode-failed')); return; }
        resolve(blob);
      }, 'image/jpeg', quality);
    };
    img.onerror = () => reject(new Error('decode-failed'));
    reader.readAsDataURL(file);
  });
}

// Componente per la foto profilo: mostra l'anteprima (o un placeholder) e un bottone che apre il
// file picker del dispositivo, ridimensiona l'immagine scelta e la carica sul bucket Storage
// "avatars" (path <userId>/avatar.jpg, sempre lo stesso nome così ogni upload sovrascrive il
// precedente). Il chiamante riceve il nuovo URL pubblico via onUploaded e lo salva su profiles.
function AvatarUploader({ userId, avatarUrl, onUploaded, langApp }) {
  const fileInputRef = React.useRef(null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const [localPreview, setLocalPreview] = useState(null);

  async function handleFileChange(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = ''; // permette di riselezionare lo stesso file una seconda volta
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setUploadError(t(langApp, 'photoTooLarge'));
      return;
    }
    setUploadError(null);
    setUploading(true);
    try {
      const blob = await resizeImageToJpeg(file);
      setLocalPreview(URL.createObjectURL(blob));
      const path = `${userId}/avatar.jpg`;
      const { error: uploadErr } = await supabase.storage.from('avatars')
        .upload(path, blob, { upsert: true, contentType: 'image/jpeg', cacheControl: '3600' });
      if (uploadErr) throw uploadErr;
      const { data } = supabase.storage.from('avatars').getPublicUrl(path);
      // cache-bust: stesso path ad ogni upload, quindi appendiamo un timestamp per forzare il
      // browser a scaricare la nuova immagine invece di servire quella vecchia dalla cache.
      const bustedUrl = `${data.publicUrl}?t=${Date.now()}`;
      onUploaded(bustedUrl);
    } catch (err) {
      setUploadError(t(langApp, 'photoUploadError'));
    } finally {
      setUploading(false);
    }
  }

  const displayUrl = localPreview || avatarUrl;
  const size = 72;

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 12 }}>
      <div style={{
        width: size, height: size, borderRadius: size / 2, background: '#3A3856',
        flexShrink: 0, overflow: 'hidden', border: '1px solid #4A4870',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {displayUrl
          ? <img src={displayUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          : <span style={{ color: '#6E6C8E', fontSize: 22 }}>?</span>}
      </div>
      <div style={{ flex: 1 }}>
        <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} style={{ display: 'none' }} />
        <button type="button" onClick={() => fileInputRef.current && fileInputRef.current.click()} disabled={uploading} style={{
          padding: '8px 14px', borderRadius: 8, border: '1px solid #4A4870',
          background: '#1B1930', color: '#D4D2E8', fontSize: 12, fontWeight: 600,
          cursor: uploading ? 'default' : 'pointer', opacity: uploading ? 0.6 : 1,
          fontFamily: '"Inter", sans-serif',
        }}>
          {uploading ? t(langApp, 'uploadingPhoto') : (avatarUrl ? t(langApp, 'changePhoto') : t(langApp, 'choosePhoto'))}
        </button>
        {avatarUrl && !uploading && (
          <button type="button" onClick={() => { setLocalPreview(null); onUploaded(null); }} style={{
            marginLeft: 8, padding: '8px 12px', borderRadius: 8, border: '1px solid #4A4870',
            background: 'transparent', color: '#9694B0', fontSize: 12, fontWeight: 600,
            cursor: 'pointer', fontFamily: '"Inter", sans-serif',
          }}>
            {t(langApp, 'removePhoto')}
          </button>
        )}
        {uploadError && <div style={{ color: '#e08a8a', fontSize: 11, marginTop: 6 }}>{uploadError}</div>}
      </div>
    </div>
  );
}

// Schermata "crea il tuo profilo", mostrata dopo il primo login/registrazione se non esiste
// ancora una riga in profiles per questo utente.
function CreateProfileScreen({ langApp, userId, onProfileCreated }) {
  const [username, setUsername] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    // lo username è case sensitive (non forziamo più il minuscolo): "Mario" e "mario"
    // restano due username distinti, come richiesto.
    const uname = username.trim();
    if (!USERNAME_REGEX.test(uname)) {
      setError(t(langApp, 'usernameInvalid'));
      return;
    }
    setLoading(true);
    try {
      const { error: insertError } = await supabase.from('profiles').insert({
        id: userId,
        username: uname,
        avatar_url: avatarUrl.trim() || null,
      });
      if (insertError) {
        // violazione univocità username: codice standard Postgres per unique_violation
        if (insertError.code === '23505') {
          setError(t(langApp, 'usernameTaken'));
        } else {
          throw insertError;
        }
        setLoading(false);
        return;
      }
      onProfileCreated({ id: userId, username: uname, avatar_url: avatarUrl.trim() || null });
    } catch (err) {
      setError(err.message || t(langApp, 'authGenericError'));
      setLoading(false);
    }
  }

  const inputStyle = {
    width: '100%', padding: '12px 14px', borderRadius: 10,
    background: '#252341', border: '1px solid #4A4870', color: '#EDEBFF',
    fontSize: 15, fontFamily: '"Inter", sans-serif', marginBottom: 6,
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #1B1930 0%, #211F38 100%)',
      color: '#EDEBFF',
      fontFamily: '"Inter", system-ui, sans-serif',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      paddingTop: 'max(20px, env(safe-area-inset-top))',
      paddingBottom: 'max(20px, env(safe-area-inset-bottom))',
      paddingLeft: 'max(20px, env(safe-area-inset-left))',
      paddingRight: 'max(20px, env(safe-area-inset-right))',
    }}>
      <div style={{ width: '100%', maxWidth: 360 }}>
        <h1 style={{ fontFamily:'"Oswald", sans-serif', fontSize: 20, fontWeight: 600, marginBottom: 8, textAlign: 'center' }}>
          {t(langApp, 'createProfileTitle')}
        </h1>
        <p style={{ color: '#9694B0', fontSize: 13, marginBottom: 20, lineHeight: 1.5, textAlign: 'center' }}>
          {t(langApp, 'createProfileIntro')}
        </p>
        <form onSubmit={handleSubmit}>
          <input type="text" value={username} onChange={e => setUsername(e.target.value)}
            placeholder={t(langApp, 'usernamePlaceholder')} autoCapitalize="none" autoCorrect="off" style={{ ...inputStyle, marginBottom: 6 }} />
          <div style={{ color: '#6E6C8E', fontSize: 11, marginBottom: 16 }}>{t(langApp, 'usernameHint')}</div>

          <div style={{ color: '#6E6C8E', fontSize: 11, marginBottom: 8 }}>{t(langApp, 'avatarUrl')}</div>
          <AvatarUploader userId={userId} avatarUrl={avatarUrl} onUploaded={setAvatarUrl} langApp={langApp} />

          {error && <div style={{ color: '#e08a8a', fontSize: 12, marginBottom: 12 }}>{error}</div>}

          <button type="submit" disabled={loading} style={{
            width: '100%', padding: '12px 14px', borderRadius: 10, border: 'none',
            background: '#5ADECD', color: '#1B1930', fontWeight: 600, fontSize: 14,
            cursor: loading ? 'default' : 'pointer', opacity: loading ? 0.6 : 1,
            fontFamily: '"Oswald", sans-serif', letterSpacing: 0.5, textTransform: 'uppercase',
            transition: 'opacity 0.15s ease',
          }}>
            {loading ? <InlineWait langApp={langApp} /> : t(langApp, 'saveProfile')}
          </button>
        </form>
      </div>
    </div>
  );
}

// Pannello "Amici": ricerca username, richieste pendenti, lista amici + riepilogo pubblico.
// Usa esclusivamente supabase-js (auth.uid() lato server per RLS) e le RPC search_profiles / get_friend_summary.
function FriendsPanel({ langApp, myUserId }) {
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState(null);
  const [sentIds, setSentIds] = useState(new Set()); // richieste inviate in questa sessione, per feedback immediato
  const [requestMsgs, setRequestMsgs] = useState({}); // per profileId: messaggio esito richiesta

  const [pending, setPending] = useState([]);
  const [loadingPending, setLoadingPending] = useState(true);
  const [friends, setFriends] = useState([]);
  const [loadingFriends, setLoadingFriends] = useState(true);

  const [summaryFor, setSummaryFor] = useState(null); // profilo amico selezionato per il riepilogo
  const [summaryData, setSummaryData] = useState(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [summaryError, setSummaryError] = useState(null);

  const debounceRef = useRef(null);

  async function loadPending() {
    setLoadingPending(true);
    const { data, error } = await supabase
      .from('friendships')
      .select('id, requester_id, status, created_at, profiles!friendships_requester_id_fkey(id, username, avatar_url)')
      .eq('addressee_id', myUserId)
      .eq('status', 'pending');
    if (!error && data) setPending(data);
    setLoadingPending(false);
  }

  async function loadFriends() {
    setLoadingFriends(true);
    const { data, error } = await supabase
      .from('friendships')
      .select('id, requester_id, addressee_id, status, requester:profiles!friendships_requester_id_fkey(id, username, avatar_url), addressee:profiles!friendships_addressee_id_fkey(id, username, avatar_url)')
      .eq('status', 'accepted')
      .or(`requester_id.eq.${myUserId},addressee_id.eq.${myUserId}`);
    if (!error && data) {
      const list = data.map(row => row.requester_id === myUserId ? row.addressee : row.requester);
      setFriends(list);
    }
    setLoadingFriends(false);
  }

  useEffect(() => {
    if (!myUserId) return;
    loadPending();
    loadFriends();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [myUserId]);

  // ricerca username con debounce ~300ms, come richiesto, per non martellare la RPC ad ogni tasto
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    const q = query.trim();
    if (q.length < 2) { setSearchResults([]); setSearchError(null); return; }
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      setSearchError(null);
      const { data, error } = await supabase.rpc('search_profiles', { p_query: q });
      if (error) {
        setSearchError(error.message || t(langApp, 'authGenericError'));
        setSearchResults([]);
      } else {
        setSearchResults(data || []);
      }
      setSearching(false);
    }, 300);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [query]);

  async function sendRequest(profile) {
    setRequestMsgs(prev => ({ ...prev, [profile.id]: null }));
    const { error } = await supabase.from('friendships').insert({
      requester_id: myUserId,
      addressee_id: profile.id,
      status: 'pending',
    });
    if (error) {
      // constraint univoco sulla coppia richiedente/destinatario già violato: messaggio gentile invece dell'errore grezzo
      const already = error.code === '23505';
      setRequestMsgs(prev => ({ ...prev, [profile.id]: already ? t(langApp, 'requestAlreadyExists') : (error.message || t(langApp, 'authGenericError')) }));
      return;
    }
    setSentIds(prev => new Set(prev).add(profile.id));
    setRequestMsgs(prev => ({ ...prev, [profile.id]: t(langApp, 'requestSent') }));
  }

  async function respondRequest(row, accept) {
    const { error } = await supabase.from('friendships').update({ status: accept ? 'accepted' : 'declined' }).eq('id', row.id);
    if (!error) {
      setPending(prev => prev.filter(p => p.id !== row.id));
      if (accept) loadFriends();
    }
  }

  async function openSummary(profile) {
    setSummaryFor(profile);
    setSummaryData(null);
    setSummaryError(null);
    setSummaryLoading(true);
    const { data, error } = await supabase.rpc('get_friend_summary', { p_user_id: profile.id });
    if (error) {
      setSummaryError(t(langApp, 'summaryLoadError'));
    } else {
      setSummaryData(data);
    }
    setSummaryLoading(false);
  }

  const cardStyle = { background: '#252341', border: '1px solid #3A3856', borderRadius: 14, padding: 14, marginBottom: 14 };
  const rowStyle = { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10, padding: '8px 0', borderBottom: '1px solid #3A3856' };
  const avatarStyle = { width: 32, height: 32, borderRadius: 16, background: '#3A3856', flexShrink: 0, objectFit: 'cover' };

  // Niente più nome visualizzato/bio: l'identità di un utente è il suo username (case sensitive),
  // con la foto profilo (se impostata) accanto.
  function ProfileRow({ profile, right }) {
    return (
      <div style={rowStyle}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
          {profile.avatar_url
            ? <img src={profile.avatar_url} alt="" style={avatarStyle} />
            : <div style={avatarStyle} />}
          <div style={{ fontSize: 13, fontWeight: 600, color: '#EDEBFF', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            @{profile.username}
          </div>
        </div>
        <div style={{ flexShrink: 0 }}>{right}</div>
      </div>
    );
  }

  return (
    <div style={cardStyle}>
      <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 12 }}>
        {t(langApp, 'friends')}
      </div>

      {/* ricerca */}
      <input type="text" value={query} onChange={e => setQuery(e.target.value)}
        placeholder={t(langApp, 'searchUsername')} autoCapitalize="none" autoCorrect="off"
        style={{
          width: '100%', padding: '10px 12px', borderRadius: 10,
          background: '#1B1930', border: '1px solid #4A4870', color: '#EDEBFF',
          fontSize: 13, fontFamily: '"Inter", sans-serif', marginBottom: 10,
        }} />

      {searching && <div style={{ fontSize: 12, color: '#9694B0', marginBottom: 8 }}><InlineWait langApp={langApp} /></div>}
      {searchError && <div style={{ fontSize: 12, color: '#e08a8a', marginBottom: 8 }}>{searchError}</div>}
      {!searching && query.trim().length >= 2 && searchResults.length === 0 && !searchError && (
        <div style={{ fontSize: 12, color: '#6E6C8E', marginBottom: 8 }}>{t(langApp, 'noResults')}</div>
      )}
      {searchResults.map(profile => (
        <ProfileRow key={profile.id} profile={profile} right={
          <div style={{ textAlign: 'right' }}>
            <button onClick={() => sendRequest(profile)} disabled={sentIds.has(profile.id)} style={{
              padding: '6px 10px', borderRadius: 8, border: '1px solid #4A4870',
              background: sentIds.has(profile.id) ? '#1B1930' : '#5ADECD',
              color: sentIds.has(profile.id) ? '#6E6C8E' : '#1B1930',
              fontSize: 11, fontWeight: 600, cursor: sentIds.has(profile.id) ? 'default' : 'pointer',
              fontFamily: '"Inter", sans-serif', transition: 'background 0.15s ease, color 0.15s ease',
            }}>
              {sentIds.has(profile.id) ? t(langApp, 'requestSent') : t(langApp, 'sendRequest')}
            </button>
            {requestMsgs[profile.id] && (
              <div style={{ fontSize: 10, color: '#9694B0', marginTop: 4, maxWidth: 140 }}>{requestMsgs[profile.id]}</div>
            )}
          </div>
        } />
      ))}

      {/* richieste ricevute */}
      <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, margin: '18px 0 8px' }}>
        {t(langApp, 'pendingRequestsReceived')}
      </div>
      {loadingPending ? (
        <div style={{ fontSize: 12, color: '#9694B0' }}><InlineWait langApp={langApp} /></div>
      ) : pending.length === 0 ? (
        <div style={{ fontSize: 12, color: '#6E6C8E' }}>{t(langApp, 'noPendingRequests')}</div>
      ) : pending.map(row => (
        <ProfileRow key={row.id} profile={row.profiles} right={
          <div style={{ display: 'flex', gap: 6 }}>
            <button onClick={() => respondRequest(row, true)} style={{
              padding: '6px 10px', borderRadius: 8, border: 'none', background: '#5ADECD', color: '#1B1930',
              fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: '"Inter", sans-serif',
              transition: 'background 0.15s ease',
            }}>{t(langApp, 'accept')}</button>
            <button onClick={() => respondRequest(row, false)} style={{
              padding: '6px 10px', borderRadius: 8, border: '1px solid #4a3a3a', background: '#2a1e1e', color: '#e08a8a',
              fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: '"Inter", sans-serif',
              transition: 'background 0.15s ease',
            }}>{t(langApp, 'decline')}</button>
          </div>
        } />
      ))}

      {/* lista amici */}
      <div style={{ fontSize: 11, color: '#9694B0', textTransform: 'uppercase', letterSpacing: 0.5, margin: '18px 0 8px' }}>
        {t(langApp, 'myFriends')}
      </div>
      {loadingFriends ? (
        <div style={{ fontSize: 12, color: '#9694B0' }}><InlineWait langApp={langApp} /></div>
      ) : friends.length === 0 ? (
        <div style={{ fontSize: 12, color: '#6E6C8E' }}>{t(langApp, 'noFriendsYet')}</div>
      ) : friends.map(profile => (
        <ProfileRow key={profile.id} profile={profile} right={
          <button onClick={() => openSummary(profile)} style={{
            padding: '6px 10px', borderRadius: 8, border: '1px solid #4A4870', background: '#1B1930', color: '#D4D2E8',
            fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: '"Inter", sans-serif',
          }}>{t(langApp, 'viewSummary')}</button>
        } />
      ))}

      {/* card riepilogo pubblico amico: SOLO aggregati, mai storico riga per riga */}
      {summaryFor && (
        <div key={summaryFor.id} className="panel-anim" style={{ marginTop: 16, background: '#1B1930', border: '1px solid #3A3856', borderRadius: 12, padding: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <span style={{ fontSize: 12.5, fontWeight: 600, color: '#EDEBFF' }}>
              {t(langApp, 'friendSummaryTitle')} — @{summaryFor.username}
            </span>
            <button onClick={() => { setSummaryFor(null); setSummaryData(null); }} style={{
              background: 'none', border: 'none', color: '#9694B0', fontSize: 14, cursor: 'pointer', padding: '6px 6px',
            }}>&times;</button>
          </div>
          {summaryLoading && <div style={{ fontSize: 12, color: '#9694B0' }}><InlineWait langApp={langApp} /></div>}
          {summaryError && <div style={{ fontSize: 12, color: '#e08a8a' }}>{summaryError}</div>}
          {summaryData && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: 12, color: '#D4D2E8' }}>
              <div>{t(langApp, 'sessions')}: <strong style={{ color: '#5ADECD' }}>{summaryData.totalSessions}</strong></div>
              <div>{t(langApp, 'sets')}: <strong style={{ color: '#5ADECD' }}>{summaryData.totalSets}</strong></div>
              <div>{t(langApp, 'totalVolume')}: <strong style={{ color: '#5ADECD' }}>{summaryData.totalVolume}</strong></div>
              <div>{t(langApp, 'firstSession')}: <strong style={{ color: '#D4D2E8' }}>{summaryData.firstDate ? fmtDate(summaryData.firstDate) : '—'}</strong></div>
              <div>{t(langApp, 'lastSession')}: <strong style={{ color: '#D4D2E8' }}>{summaryData.lastDate ? fmtDate(summaryData.lastDate) : '—'}</strong></div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Schermata di accesso: registrazione o login con codice personale
function AuthScreen({ onAuthenticated, langApp }) {
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // pulizia silenziosa in background: rimuove eventuali codici registrati e mai completati
  // con un export (rete di sicurezza nel caso l'utente chiuda l'app invece di tornare indietro)
  useEffect(() => {
    cleanupAbandonedAccounts().catch(() => {});
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    const trimmed = code.trim();
    if (trimmed.length < 4) {
      setError(langApp === 'en' ? 'The code must be at least 4 characters.' : 'Il codice deve avere almeno 4 caratteri.');
      return;
    }
    setLoading(true);
    try {
      const userId = mode === 'register' ? await registerCode(trimmed) : await loginCode(trimmed);
      localStorage_set(LOCAL_STORAGE_KEY, userId);
      onAuthenticated(userId, mode === 'register');
    } catch (err) {
      setError(err.message || (langApp === 'en' ? 'Unexpected error. Please try again.' : 'Errore imprevisto. Riprova.'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #1B1930 0%, #211F38 100%)',
      color: '#EDEBFF',
      fontFamily: '"Inter", system-ui, sans-serif',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      paddingTop: 'max(20px, env(safe-area-inset-top))',
      paddingBottom: 'max(20px, env(safe-area-inset-bottom))',
      paddingLeft: 'max(20px, env(safe-area-inset-left))',
      paddingRight: 'max(20px, env(safe-area-inset-right))',
    }}>
      <style dangerouslySetInnerHTML={{__html: `
        * { box-sizing: border-box; }
      `}} />
      <div style={{ width: '100%', maxWidth: 360 }}>
        <h1 style={{ fontFamily:'"Oswald", sans-serif', fontSize: 22, fontWeight: 500, marginBottom: 4, textAlign: 'center', color: '#EDEBFF' }}>
          {t(langApp, 'subtitle')}
        </h1>
        <p style={{ color: '#9694B0', fontSize: 13, marginBottom: 24, lineHeight: 1.5 }}>
          {mode === 'register' ? t(langApp, 'chooseCode') : t(langApp, 'enterCode')}
        </p>

        <div style={{ display: 'flex', gap: 8, marginBottom: 20, background: '#1a1a1a', padding: 4, borderRadius: 8 }}>
          <button onClick={() => { setMode('login'); setError(null); }} style={{
            flex: 1, padding: '8px 12px', borderRadius: 6, border: 'none', cursor: 'pointer',
            fontFamily: '"Oswald", sans-serif', fontSize: 12, letterSpacing: 0.5, textTransform: 'uppercase',
            background: mode === 'login' ? '#5ADECD' : 'transparent',
            color: mode === 'login' ? '#1B1930' : '#9694B0',
            transition: 'background 0.15s ease, color 0.15s ease',
          }}>{t(langApp, 'login')}</button>
          <button onClick={() => { setMode('register'); setError(null); }} style={{
            flex: 1, padding: '8px 12px', borderRadius: 6, border: 'none', cursor: 'pointer',
            fontFamily: '"Oswald", sans-serif', fontSize: 12, letterSpacing: 0.5, textTransform: 'uppercase',
            background: mode === 'register' ? '#5ADECD' : 'transparent',
            color: mode === 'register' ? '#1B1930' : '#9694B0',
            transition: 'background 0.15s ease, color 0.15s ease',
          }}>{t(langApp, 'register')}</button>
        </div>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={code}
            onChange={e => setCode(e.target.value)}
            placeholder={t(langApp, 'codePlaceholder')}
            autoCapitalize="none"
            autoCorrect="off"
            style={{
              width: '100%', padding: '12px 14px', borderRadius: 10,
              background: '#252341', border: '1px solid #4A4870', color: '#EDEBFF',
              fontSize: 15, fontFamily: '"Inter", sans-serif', marginBottom: 12,
            }}
          />
          {error && (
            <div style={{ color: '#e08a8a', fontSize: 12, marginBottom: 12 }}>{error}</div>
          )}
          <button type="submit" disabled={loading} style={{
            width: '100%', padding: '12px 14px', borderRadius: 10, border: 'none',
            background: '#5ADECD', color: '#1B1930', fontWeight: 600, fontSize: 14,
            cursor: loading ? 'default' : 'pointer', opacity: loading ? 0.6 : 1,
            fontFamily: '"Oswald", sans-serif', letterSpacing: 0.5, textTransform: 'uppercase',
            transition: 'opacity 0.15s ease',
          }}>
            {loading ? t(langApp, 'pleaseWait') : (mode === 'register' ? t(langApp, 'createAccount') : t(langApp, 'login'))}
          </button>
        </form>
      </div>
    </div>
  );
}

// Schermata di richiesta primo export, dopo il login se l'utente non ha ancora dati
function FirstUploadScreen({ onUpload, uploading, error, langApp, onBack, importApp, onChangeImportApp }) {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #1B1930 0%, #211F38 100%)',
      color: '#EDEBFF',
      fontFamily: '"Inter", system-ui, sans-serif',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      paddingTop: 'max(20px, env(safe-area-inset-top))',
      paddingBottom: 'max(20px, env(safe-area-inset-bottom))',
      paddingLeft: 'max(20px, env(safe-area-inset-left))',
      paddingRight: 'max(20px, env(safe-area-inset-right))',
      position: 'relative',
    }}>
      <button onClick={onBack} style={{
        position: 'absolute', top: 'max(20px, env(safe-area-inset-top))', left: 'max(20px, env(safe-area-inset-left))',
        background: 'none', border: 'none', color: '#9694B0', fontSize: 20,
        cursor: 'pointer', padding: 8, lineHeight: 1,
      }} aria-label={t(langApp, 'back')}>
        &#8592;
      </button>
      <div style={{ width: '100%', maxWidth: 360, textAlign: 'center' }}>
        <h1 style={{ fontFamily:'"Oswald", sans-serif', fontSize: 22, fontWeight: 600, marginBottom: 8 }}>
          {t(langApp, 'uploadTitle')}
        </h1>
        <p style={{ color: '#9694B0', fontSize: 13, marginBottom: 24, lineHeight: 1.5 }}>
          {t(langApp, 'uploadSubtitle')}
        </p>
        <div style={{ textAlign: 'left', marginBottom: 14 }}>
          <ImportAppSelector value={importApp} onChange={onChangeImportApp} langApp={langApp} />
        </div>
        <label style={{
          display: 'block', padding: '14px 20px', borderRadius: 10,
          background: '#5ADECD', color: '#1B1930', fontWeight: 600, fontSize: 14,
          cursor: uploading ? 'default' : 'pointer', opacity: uploading ? 0.6 : 1,
          fontFamily: '"Oswald", sans-serif', letterSpacing: 0.5, textTransform: 'uppercase',
          transition: 'opacity 0.15s ease',
        }}>
          {uploading ? t(langApp, 'uploading') : t(langApp, 'chooseFile')}
          <input type="file" accept=".csv" onChange={onUpload} disabled={uploading} style={{ display: 'none' }} />
        </label>
        {error && <div style={{ color: '#e08a8a', fontSize: 12, marginTop: 12 }}>{error}</div>}
      </div>
    </div>
  );
}

function localStorage_get(key) {
  try { return localStorage.getItem(key); } catch (e) { return null; }
}
function localStorage_set(key, value) {
  try { localStorage.setItem(key, value); } catch (e) {}
}
function localStorage_remove(key) {
  try { localStorage.removeItem(key); } catch (e) {}
}

export default function App() {
  // --- Nuovo sistema di autenticazione (Supabase Auth) ---
  // authSession: sessione Supabase Auth corrente (null finché non loggati con email/password o Google).
  // authChecking: true mentre verifichiamo se esiste già una sessione persistita (getSession).
  // profile: riga in public.profiles per l'utente autenticato; null finché non creata (mostra CreateProfileScreen).
  const [authSession, setAuthSession] = useState(null);
  const [authChecking, setAuthChecking] = useState(true);
  const [profile, setProfile] = useState(null);
  const [profileChecking, setProfileChecking] = useState(false);
  // schermata di ingresso corrente quando non c'è ancora sessione Auth: 'main' (email/password) o 'legacyMigration'
  const [entryScreen, setEntryScreen] = useState('main');

  const [userId, setUserId] = useState(null);
  const [checkingSession, setCheckingSession] = useState(true);
  const [remoteData, setRemoteData] = useState(null); // null = non ancora caricato
  const [loadError, setLoadError] = useState(null);
  const [uploadingFirst, setUploadingFirst] = useState(false);
  const [firstUploadError, setFirstUploadError] = useState(null);
  // true se l'utente è appena arrivato da una registrazione (nuovo codice creato in questa sessione):
  // se torna indietro dalla schermata di primo upload senza caricare nulla, il codice va cancellato
  // invece di restare "sciolto" nel database senza dati.
  const [justRegistered, setJustRegistered] = useState(false);
  // app di provenienza scelta per il primo upload (selezione manuale, non auto-detect) + stato
  // di mappatura manuale colonne quando l'utente sceglie "Altro formato CSV"
  const [firstUploadImportApp, setFirstUploadImportApp] = useState('liftoff');
  const [firstUploadMappingState, setFirstUploadMappingState] = useState(null); // { headers, file }
  const [langApp, setLangApp] = useState(() => localStorage_get(LANG_APP_KEY) || 'it');
  const [langExercise, setLangExercise] = useState(() => localStorage_get(LANG_EXERCISE_KEY) || 'it');
  const [weightUnit, setWeightUnit] = useState(() => localStorage_get(UNITS_KEY) || 'kg');

  function changeLangApp(lang) {
    setLangApp(lang);
    localStorage_set(LANG_APP_KEY, lang);
  }
  function changeLangExercise(lang) {
    setLangExercise(lang);
    localStorage_set(LANG_EXERCISE_KEY, lang);
  }
  function changeWeightUnit(unit) {
    setWeightUnit(unit);
    localStorage_set(UNITS_KEY, unit);
  }

  // al primo avvio, controlla se esiste già una sessione Supabase Auth persistita (localStorage),
  // e resta in ascolto di login/logout/refresh token tramite onAuthStateChange.
  useEffect(() => {
    let cancelled = false;
    supabase.auth.getSession().then(({ data }) => {
      if (cancelled) return;
      setAuthSession(data.session || null);
      setAuthChecking(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setAuthSession(session);
    });
    return () => { cancelled = true; listener?.subscription?.unsubscribe(); };
  }, []);

  // quando cambia la sessione Auth, verifica se esiste già un profilo per questo utente;
  // se la sessione sparisce (logout), ripulisce anche lo stato "vecchio flusso" collegato.
  useEffect(() => {
    if (!authSession) {
      setProfile(null);
      return;
    }
    let cancelled = false;
    setProfileChecking(true);
    supabase.from('profiles').select('*').eq('id', authSession.user.id).maybeSingle()
      .then(({ data, error }) => {
        if (cancelled) return;
        if (!error && data) setProfile(data);
        setProfileChecking(false);
      });
    return () => { cancelled = true; };
  }, [authSession]);

  // quando abbiamo sessione Auth + profilo pronti, lo userId "storico" (usato da tutta la logica
  // dati/workout esistente, invariata) diventa auth.uid(): le RPC legacy accettano p_user_id generico
  // quindi funzionano identiche anche per i nuovi account autenticati.
  useEffect(() => {
    if (authSession && profile) {
      setUserId(authSession.user.id);
      setCheckingSession(false);
    }
  }, [authSession, profile]);

  // quando abbiamo uno userId (da sessione salvata o da login), carica i dati dal server
  useEffect(() => {
    if (!userId) return;
    let cancelled = false;
    setLoadError(null);
    getWorkoutData(userId)
      .then(data => { if (!cancelled) { setRemoteData(data); setCheckingSession(false); } })
      .catch(err => {
        if (!cancelled) {
          setLoadError(err.message || 'Impossibile caricare i dati.');
          setCheckingSession(false);
          // sessione salvata non più valida (es. account cancellato): puliamo
          localStorage_remove(LOCAL_STORAGE_KEY);
          setUserId(null);
        }
      });
    return () => { cancelled = true; };
  }, [userId]);

  function handleAuthenticated(newUserId, wasRegister) {
    setJustRegistered(!!wasRegister);
    setUserId(newUserId);
  }

  function handleLogout() {
    // il logout ora deve invalidare anche la sessione Supabase Auth vera, non solo lo stato locale
    supabase.auth.signOut().catch(err => console.error('Errore signOut:', err));
    localStorage_remove(LOCAL_STORAGE_KEY);
    setUserId(null);
    setRemoteData(null);
    setLoadError(null);
    setJustRegistered(false);
    setProfile(null);
    setEntryScreen('main');
  }

  // l'utente ha appena creato un account (codice legacy oppure email/password) ma torna indietro
  // senza caricare l'export: l'account non ha ancora dati, quindi lo eliminiamo per non lasciarlo
  // "sciolto" nel database. Con Supabase Auth, "account" include anche la riga auth.users vera e
  // il profilo: usiamo delete_own_auth_account (RPC dedicata) invece della delete_account legacy,
  // che opera solo sulla vecchia tabella access_codes e non toccherebbe nulla per questi utenti.
  async function handleAbandonFirstUpload() {
    const idToClean = userId;
    const wasAuthAccount = !!authSession;
    localStorage_remove(LOCAL_STORAGE_KEY);
    setUserId(null);
    setRemoteData(null);
    setLoadError(null);
    setJustRegistered(false);
    setProfile(null);
    try {
      if (wasAuthAccount) {
        await supabase.rpc('delete_own_auth_account');
        await supabase.auth.signOut();
      } else if (idToClean) {
        await deleteAccount(idToClean);
      }
    } catch (err) {
      console.error('Errore pulizia account abbandonato:', err);
    }
  }

  async function handleDeleteAccount() {
    if (!userId) return;
    const wasAuthAccount = !!authSession;
    try {
      if (wasAuthAccount) {
        await supabase.rpc('delete_own_auth_account');
      } else {
        await deleteAccount(userId);
      }
    } catch (err) {
      console.error('Errore eliminazione account:', err);
    } finally {
      // in ogni caso riportiamo l'utente al login: se l'account non esisteva più era comunque da pulire localmente
      supabase.auth.signOut().catch(() => {});
      localStorage_remove(LOCAL_STORAGE_KEY);
      setUserId(null);
      setRemoteData(null);
      setLoadError(null);
      setProfile(null);
    }
  }

  function handleDataChange(newRaw) {
    if (!userId) return;
    setWorkoutDataRemote(userId, newRaw).catch(err => {
      console.error('Errore salvataggio dati:', err);
    });
  }

  // salva su backend le righe convertite del primo export, comune a tutti i percorsi (app dirette o mappatura manuale)
  async function saveFirstUploadRows(newRows) {
    if (newRows.length === 0) {
      setFirstUploadError(t(langApp, 'importNoValidRows'));
      setUploadingFirst(false);
      return;
    }
    try {
      await setWorkoutDataRemote(userId, newRows);
      setRemoteData(newRows);
      setJustRegistered(false); // ora l'account ha dati, non va più cancellato tornando indietro
    } catch (err) {
      setFirstUploadError(err.message || 'Errore nel salvataggio.');
    } finally {
      setUploadingFirst(false);
    }
  }

  function handleFirstUpload(e) {
    const file = e.target.files[0];
    if (!file) return;
    setFirstUploadError(null);
    // "Altro formato CSV": leggiamo prima solo l'header per far scegliere la mappatura, poi
    // applichiamo la mappatura a tutto il file in un secondo passaggio (vedi handleConfirmFirstUploadMapping).
    if (firstUploadImportApp === 'other') {
      setUploadingFirst(true);
      Papa.parse(file, {
        header: true, skipEmptyLines: true, preview: 1,
        complete: (previewResult) => {
          const headers = previewResult.meta && previewResult.meta.fields ? previewResult.meta.fields : [];
          setUploadingFirst(false);
          if (!headers.length) {
            setFirstUploadError(t(langApp, 'importParseError'));
            return;
          }
          setFirstUploadMappingState({ headers, file });
        },
        error: (err) => {
          setUploadingFirst(false);
          setFirstUploadError(`${t(langApp, 'importParseError')}: ${err.message}`);
        }
      });
      e.target.value = '';
      return;
    }
    setUploadingFirst(true);
    Papa.parse(file, {
      ...papaOptionsForImportApp(firstUploadImportApp),
      complete: async (results) => {
        try {
          const { rows: newRows } = rowsForImportApp(firstUploadImportApp, results.data);
          await saveFirstUploadRows(newRows);
        } catch (err) {
          setFirstUploadError(err.message || t(langApp, 'importParseError'));
          setUploadingFirst(false);
        }
      },
      error: (err) => {
        setFirstUploadError(`${t(langApp, 'importParseError')}: ${err.message}`);
        setUploadingFirst(false);
      }
    });
    e.target.value = '';
  }

  function handleConfirmFirstUploadMapping(mapping, defaultWeightUnit) {
    const file = firstUploadMappingState.file;
    setFirstUploadMappingState(null);
    setUploadingFirst(true);
    Papa.parse(file, {
      header: true, skipEmptyLines: true,
      complete: async (results) => {
        try {
          const newRows = mappedRowsToRaw(results.data, mapping, defaultWeightUnit);
          await saveFirstUploadRows(newRows);
        } catch (err) {
          setFirstUploadError(err.message || t(langApp, 'importParseError'));
          setUploadingFirst(false);
        }
      },
      error: (err) => {
        setFirstUploadError(`${t(langApp, 'importParseError')}: ${err.message}`);
        setUploadingFirst(false);
      }
    });
  }

  // --- Instradamento del nuovo flusso di ingresso ---
  // 1) attesa verifica sessione Auth (getSession)
  if (authChecking) {
    return (
      <div style={{ minHeight: '100vh', background: '#1B1930', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9694B0', fontFamily: 'sans-serif', fontSize: 14 }}>
        {t(langApp, 'loading')}
      </div>
    );
  }

  // 2) nessuna sessione Auth: mostra tab Accedi/Registrati, oppure il flusso di recupero da codice legacy
  if (!authSession) {
    if (entryScreen === 'legacyMigration') {
      return (
        <LegacyMigrationFlow
          langApp={langApp}
          onBack={() => setEntryScreen('main')}
          onMigrated={() => setEntryScreen('main')}
        />
      );
    }
    return (
      <EmailAuthScreen
        langApp={langApp}
        onAuthSession={(session, wasJustCreated) => {
          if (wasJustCreated) setJustRegistered(true);
          setAuthSession(session);
        }}
        onStartLegacyMigration={() => setEntryScreen('legacyMigration')}
      />
    );
  }

  // 3) sessione Auth presente ma verifica/creazione profilo ancora in corso
  if (profileChecking) {
    return (
      <div style={{ minHeight: '100vh', background: '#1B1930', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9694B0', fontFamily: 'sans-serif', fontSize: 14 }}>
        {t(langApp, 'loading')}
      </div>
    );
  }

  // 4) sessione Auth presente ma nessun profilo ancora: obbliga a crearne uno prima di procedere
  if (!profile) {
    return (
      <CreateProfileScreen
        langApp={langApp}
        userId={authSession.user.id}
        onProfileCreated={(newProfile) => setProfile(newProfile)}
      />
    );
  }

  // --- Da qui in poi: login+profilo completati, resta invariata la logica dati esistente ---
  if (checkingSession) {
    return (
      <div style={{ minHeight: '100vh', background: '#1B1930', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9694B0', fontFamily: 'sans-serif', fontSize: 14 }}>
        {t(langApp, 'loading')}
      </div>
    );
  }

  if (!userId) {
    // caso limite: sessione+profilo pronti ma userId non ancora propagato (frame successivo lo imposterà)
    return (
      <div style={{ minHeight: '100vh', background: '#1B1930', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9694B0', fontFamily: 'sans-serif', fontSize: 14 }}>
        {t(langApp, 'loading')}
      </div>
    );
  }

  if (loadError) {
    return (
      <div style={{ minHeight: '100vh', background: '#1B1930', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#e08a8a', fontFamily: 'sans-serif', fontSize: 14, padding: 20, textAlign: 'center' }}>
        {loadError}
      </div>
    );
  }

  if (remoteData === null) {
    return (
      <div style={{ minHeight: '100vh', background: '#1B1930', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#9694B0', fontFamily: 'sans-serif', fontSize: 14 }}>
        {t(langApp, 'loadingData')}
      </div>
    );
  }

  if (remoteData.length === 0) {
    return (
      <>
        <FirstUploadScreen
          onUpload={handleFirstUpload} uploading={uploadingFirst} error={firstUploadError} langApp={langApp}
          onBack={justRegistered ? handleAbandonFirstUpload : handleLogout}
          importApp={firstUploadImportApp} onChangeImportApp={setFirstUploadImportApp}
        />
        {firstUploadMappingState && (
          <ImportMappingModal
            headers={firstUploadMappingState.headers}
            langApp={langApp}
            defaultWeightUnit={weightUnit}
            onCancel={() => setFirstUploadMappingState(null)}
            onConfirm={handleConfirmFirstUploadMapping}
          />
        )}
      </>
    );
  }

  return <WorkoutBodyExplorer
    initialRaw={remoteData} userId={userId} onDataChange={handleDataChange} onLogout={handleLogout} onDeleteAccount={handleDeleteAccount}
    langApp={langApp} langExercise={langExercise} weightUnit={weightUnit}
    onChangeLangApp={changeLangApp} onChangeLangExercise={changeLangExercise} onChangeWeightUnit={changeWeightUnit}
    profile={profile} onProfileUpdated={setProfile}
  />;
}
